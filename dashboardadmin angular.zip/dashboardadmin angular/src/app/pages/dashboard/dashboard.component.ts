import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { CardComponent } from '../../shared/components/card/card.component';
import { StatCardComponent } from '../../shared/components/stat-card/stat-card.component';
import { ChartComponent } from '../../shared/components/chart/chart.component';
import { DateFilterComponent } from '../../shared/components/date-filter/date-filter.component';
import { SalesService } from '../../core/services/sales.service';
import { UserService } from '../../core/services/user.service';
import { ProductService } from '../../core/services/product.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    PageHeaderComponent,
    CardComponent,
    StatCardComponent,
    ChartComponent,
    DateFilterComponent
  ],
  template: `
    <div class="dashboard">
      <app-page-header title="Dashboard" subtitle="Welcome to your admin dashboard"></app-page-header>
      
      <app-date-filter (filterChange)="onFilterChange($event)"></app-date-filter>
      
      <div class="stat-cards">
        <app-stat-card
          title="Total Sales"
          [value]="'$' + totalRevenue.toFixed(2)"
          [change]="revenueChange"
          changeLabel="vs previous period"
          type="primary"
          [icon]="salesIcon"
        ></app-stat-card>
        
        <app-stat-card
          title="Orders"
          [value]="totalOrders.toString()"
          [change]="ordersChange"
          changeLabel="vs previous period"
          type="success"
          [icon]="ordersIcon"
        ></app-stat-card>
        
        <app-stat-card
          title="Average Order"
          [value]="'$' + averageOrder.toFixed(2)"
          [change]="averageOrderChange"
          changeLabel="vs previous period"
          type="info"
          [icon]="averageIcon"
        ></app-stat-card>
        
        <app-stat-card
          title="Active Users"
          [value]="activeUsers.toString()"
          [change]="activeUsersChange"
          changeLabel="vs previous period"
          type="warning"
          [icon]="usersIcon"
        ></app-stat-card>
      </div>
      
      <div class="dashboard-row">
        <app-card title="Sales Trend" subtitle="Revenue over time" class="chart-card">
          <app-chart [type]="'line'" [data]="salesChartData"></app-chart>
        </app-card>
        
        <app-card title="Sales by Payment Method" class="chart-card">
          <app-chart [type]="'doughnut'" [data]="paymentChartData"></app-chart>
        </app-card>
      </div>
      
      <div class="dashboard-row">
        <app-card title="Expiring Products" subtitle="Products expiring soon" class="table-card">
          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Expires</th>
                  <th>Stock</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngIf="expiringProducts.length === 0">
                  <td colspan="4" class="empty-message">No expiring products in the next 30 days</td>
                </tr>
                <tr *ngFor="let product of expiringProducts">
                  <td>
                    <div class="product-cell">
                      <img [src]="product.image || 'https://via.placeholder.com/40x40'" alt="{{ product.name }}" class="product-image" />
                      <div class="product-info">
                        <div class="product-name">{{ product.name }}</div>
                        <div class="product-category">{{ product.category }}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span 
                      [class.expiring-soon]="isDaysDifference(product.expirationDate, 7)"
                      [class.expiring-warning]="isDaysDifference(product.expirationDate, 14) && !isDaysDifference(product.expirationDate, 7)"
                    >
                      {{ product.expirationDate | date:'MMM d, y' }}
                      <small *ngIf="isDaysDifference(product.expirationDate, 7)">({{ getDaysDifference(product.expirationDate) }} days)</small>
                    </span>
                  </td>
                  <td>{{ product.stockQuantity }}</td>
                  <td>
                    <span class="status-badge" [class]="'status-' + product.status.toLowerCase()">
                      {{ formatStatus(product.status) }}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div card-footer>
            <a routerLink="/products" class="view-all">
              View all products
              <svg xmlns="http://www.w3.org/2000/svg" height="16" viewBox="0 -960 960 960" width="16" fill="currentColor">
                <path d="M530-481 332-679l43-43 241 241-241 241-43-43 198-198Z"/>
              </svg>
            </a>
          </div>
        </app-card>
        
        <app-card title="Recent Sales" subtitle="Latest transactions" class="table-card">
          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>Customer</th>
                  <th>Date</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngIf="recentSales.length === 0">
                  <td colspan="4" class="empty-message">No recent sales</td>
                </tr>
                <tr *ngFor="let sale of recentSales">
                  <td>{{ sale.customerName || 'Walk-in Customer' }}</td>
                  <td>{{ sale.createdAt | date:'short' }}</td>
                  <td>{{ sale.total.toFixed(2) }}</td>
                  <td>
                    <span class="status-badge" [class]="'status-' + sale.status.toLowerCase()">
                      {{ sale.status }}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div card-footer>
            <a routerLink="/sales" class="view-all">
              View all sales
              <svg xmlns="http://www.w3.org/2000/svg" height="16" viewBox="0 -960 960 960" width="16" fill="currentColor">
                <path d="M530-481 332-679l43-43 241 241-241 241-43-43 198-198Z"/>
              </svg>
            </a>
          </div>
        </app-card>
      </div>
    </div>
  `,
  styles: [`
    .dashboard {
      padding: var(--spacing-3);
    }
    
    .stat-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: var(--spacing-3);
      margin-bottom: var(--spacing-3);
    }
    
    .dashboard-row {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
      gap: var(--spacing-3);
      margin-bottom: var(--spacing-3);
    }
    
    .chart-card {
      height: 400px;
    }
    
    .table-card {
      height: 100%;
    }
    
    .table-responsive {
      overflow-x: auto;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
    }
    
    th {
      text-align: left;
      padding: var(--spacing-2);
      border-bottom: 2px solid var(--neutral-200);
      font-weight: 500;
      color: var(--neutral-700);
    }
    
    td {
      padding: var(--spacing-2);
      border-bottom: 1px solid var(--neutral-200);
    }
    
    tr:hover td {
      background-color: var(--neutral-50);
    }
    
    .empty-message {
      text-align: center;
      color: var(--neutral-500);
      padding: var(--spacing-3) !important;
    }
    
    .product-cell {
      display: flex;
      align-items: center;
    }
    
    .product-image {
      width: 32px;
      height: 32px;
      border-radius: var(--radius-sm);
      margin-right: var(--spacing-1);
      object-fit: cover;
    }
    
    .product-info {
      display: flex;
      flex-direction: column;
    }
    
    .product-name {
      font-weight: 500;
    }
    
    .product-category {
      font-size: 0.75rem;
      color: var(--neutral-600);
    }
    
    .expiring-soon {
      color: var(--error);
      font-weight: 500;
    }
    
    .expiring-warning {
      color: var(--warning);
    }
    
    .view-all {
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--primary-600);
      text-decoration: none;
      font-weight: 500;
      transition: color var(--transition-fast);
    }
    
    .view-all:hover {
      color: var(--primary-700);
    }
    
    .view-all svg {
      margin-left: var(--spacing-1);
    }
    
    @media (max-width: 1024px) {
      .dashboard-row {
        grid-template-columns: 1fr;
      }
    }
    
    @media (max-width: 600px) {
      .stat-cards {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class DashboardComponent {
  // Sales metrics
  totalRevenue = 0;
  totalOrders = 0;
  averageOrder = 0;
  activeUsers = 0;
  
  // Change percentages
  revenueChange = 0;
  ordersChange = 0;
  averageOrderChange = 0;
  activeUsersChange = 0;
  
  // Chart data
  salesChartData: any = {
    labels: [],
    datasets: []
  };
  
  paymentChartData: any = {
    labels: [],
    datasets: []
  };
  
  // Tables data
  expiringProducts: any[] = [];
  recentSales: any[] = [];
  
  // Icons templates
  salesIcon = {
    createEmbeddedView: () => {}
  };
  
  ordersIcon = {
    createEmbeddedView: () => {}
  };
  
  averageIcon = {
    createEmbeddedView: () => {}
  };
  
  usersIcon = {
    createEmbeddedView: () => {}
  };
  
  constructor(
    private salesService: SalesService,
    private userService: UserService,
    private productService: ProductService
  ) {
    this.loadDashboardData('month');
  }
  
  onFilterChange(filter: {type: string, startDate?: Date, endDate?: Date}): void {
    this.loadDashboardData(filter.type, filter.startDate, filter.endDate);
  }
  
  loadDashboardData(filterType: string, startDate?: Date, endDate?: Date): void {
    let filteredSales: any[] = [];
    
    // Get sales based on filter
    if (filterType === 'day') {
      filteredSales = this.salesService.getSalesByDay(new Date());
    } else if (filterType === 'week') {
      filteredSales = this.salesService.getSalesByWeek(new Date());
    } else if (filterType === 'month') {
      filteredSales = this.salesService.getSalesByMonth(new Date());
    } else if (filterType === 'year') {
      filteredSales = this.salesService.getSalesByYear(new Date());
    } else if (filterType === 'custom' && startDate && endDate) {
      filteredSales = this.salesService.filterSalesByDateRange(startDate, endDate);
    }
    
    // Calculate metrics
    this.calculateMetrics(filteredSales, filterType);
    
    // Get expiring products
    this.expiringProducts = this.productService.getExpiringProducts(30).slice(0, 5);
    
    // Get recent sales
    this.recentSales = [...this.salesService.sales]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
    
    // Update charts
    this.updateCharts(filteredSales, filterType);
  }
  
  calculateMetrics(sales: any[], filterType: string): void {
    // Current period metrics
    this.totalRevenue = sales.reduce((sum, sale) => sum + sale.total, 0);
    this.totalOrders = sales.length;
    this.averageOrder = this.totalOrders > 0 ? this.totalRevenue / this.totalOrders : 0;
    this.activeUsers = this.userService.getActiveUsers().length;
    
    // Calculate previous period for comparison
    const today = new Date();
    let previousSales: any[] = [];
    
    if (filterType === 'day') {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      previousSales = this.salesService.getSalesByDay(yesterday);
    } else if (filterType === 'week') {
      const lastWeekStart = new Date(today);
      lastWeekStart.setDate(lastWeekStart.getDate() - 7);
      previousSales = this.salesService.getSalesByWeek(lastWeekStart);
    } else if (filterType === 'month') {
      const lastMonth = new Date(today);
      lastMonth.setMonth(lastMonth.getMonth() - 1);
      previousSales = this.salesService.getSalesByMonth(lastMonth);
    } else if (filterType === 'year') {
      const lastYear = new Date(today);
      lastYear.setFullYear(lastYear.getFullYear() - 1);
      previousSales = this.salesService.getSalesByYear(lastYear);
    } else if (filterType === 'custom') {
      // For custom, we'll just use a mock value
      previousSales = sales.slice(0, Math.floor(sales.length * 0.8));
    }
    
    // Calculate previous period metrics
    const prevTotalRevenue = previousSales.reduce((sum, sale) => sum + sale.total, 0);
    const prevTotalOrders = previousSales.length;
    const prevAverageOrder = prevTotalOrders > 0 ? prevTotalRevenue / prevTotalOrders : 0;
    
    // Calculate change percentages
    this.revenueChange = this.calculatePercentageChange(prevTotalRevenue, this.totalRevenue);
    this.ordersChange = this.calculatePercentageChange(prevTotalOrders, this.totalOrders);
    this.averageOrderChange = this.calculatePercentageChange(prevAverageOrder, this.averageOrder);
    
    // Mock user change for demo purposes
    this.activeUsersChange = 5.2;
  }
  
  updateCharts(sales: any[], filterType: string): void {
    // Prepare line chart data
    this.prepareSalesChart(sales, filterType);
    
    // Prepare doughnut chart data
    this.preparePaymentMethodChart(sales);
  }
  
  prepareSalesChart(sales: any[], filterType: string): void {
    let labels: string[] = [];
    let revenues: number[] = [];
    
    // Group sales by date
    const salesByDate = new Map<string, number>();
    
    if (filterType === 'day') {
      // Group by hour for day view
      for (let i = 0; i < 24; i++) {
        const hourLabel = `${i}:00`;
        salesByDate.set(hourLabel, 0);
      }
      
      sales.forEach(sale => {
        const date = new Date(sale.createdAt);
        const hourLabel = `${date.getHours()}:00`;
        salesByDate.set(hourLabel, (salesByDate.get(hourLabel) || 0) + sale.total);
      });
    } else if (filterType === 'week') {
      // Group by day for week view
      const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      daysOfWeek.forEach(day => salesByDate.set(day, 0));
      
      sales.forEach(sale => {
        const date = new Date(sale.createdAt);
        const dayLabel = daysOfWeek[date.getDay()];
        salesByDate.set(dayLabel, (salesByDate.get(dayLabel) || 0) + sale.total);
      });
    } else if (filterType === 'month') {
      // Group by day for month view
      const today = new Date();
      const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
      
      for (let i = 1; i <= daysInMonth; i++) {
        salesByDate.set(`${i}`, 0);
      }
      
      sales.forEach(sale => {
        const date = new Date(sale.createdAt);
        const dayLabel = `${date.getDate()}`;
        salesByDate.set(dayLabel, (salesByDate.get(dayLabel) || 0) + sale.total);
      });
    } else if (filterType === 'year') {
      // Group by month for year view
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      months.forEach(month => salesByDate.set(month, 0));
      
      sales.forEach(sale => {
        const date = new Date(sale.createdAt);
        const monthLabel = months[date.getMonth()];
        salesByDate.set(monthLabel, (salesByDate.get(monthLabel) || 0) + sale.total);
      });
    } else if (filterType === 'custom') {
      // For custom, group by day
      const dateMap = new Map<string, number>();
      
      sales.forEach(sale => {
        const date = new Date(sale.createdAt);
        const dateStr = date.toISOString().split('T')[0];
        dateMap.set(dateStr, (dateMap.get(dateStr) || 0) + sale.total);
      });
      
      // Sort dates
      const sortedDates = Array.from(dateMap.keys()).sort();
      
      sortedDates.forEach(dateStr => {
        const date = new Date(dateStr);
        labels.push(date.toLocaleDateString());
        revenues.push(dateMap.get(dateStr) || 0);
      });
    }
    
    // Convert map to arrays if not custom
    if (filterType !== 'custom') {
      labels = Array.from(salesByDate.keys());
      revenues = Array.from(salesByDate.values());
    }
    
    // Create chart data
    this.salesChartData = {
      labels,
      datasets: [
        {
          label: 'Revenue',
          data: revenues,
          borderColor: '#607D2F',
          backgroundColor: 'rgba(96, 125, 47, 0.1)',
          fill: true,
          tension: 0.4
        }
      ]
    };
  }
  
  preparePaymentMethodChart(sales: any[]): void {
    // Count sales by payment method
    const paymentCounts = new Map<string, number>();
    const paymentMethods = ['CASH', 'CREDIT_CARD', 'DEBIT_CARD', 'BANK_TRANSFER', 'OTHER'];
    
    paymentMethods.forEach(method => paymentCounts.set(method, 0));
    
    sales.forEach(sale => {
      paymentCounts.set(sale.paymentMethod, (paymentCounts.get(sale.paymentMethod) || 0) + 1);
    });
    
    // Create chart data
    this.paymentChartData = {
      labels: Array.from(paymentCounts.keys()).map(this.formatPaymentMethod),
      datasets: [
        {
          data: Array.from(paymentCounts.values()),
          backgroundColor: [
            '#607D2F',  // Primary
            '#84AD33',  // Primary lighter
            '#A6CA59',  // Primary lightest
            '#4CAF50',  // Success
            '#9E9E9E'   // Neutral
          ],
          borderWidth: 1
        }
      ]
    };
  }
  
  calculatePercentageChange(previous: number, current: number): number {
    if (previous === 0) return current > 0 ? 100 : 0;
    return parseFloat(((current - previous) / previous * 100).toFixed(1));
  }
  
  formatPaymentMethod(method: string): string {
    return method.replace('_', ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
  }
  
  formatStatus(status: string): string {
    return status.replace('_', ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
  }
  
  isDaysDifference(dateStr: string | Date | undefined, days: number): boolean {
    if (!dateStr) return false;
    
    const expirationDate = new Date(dateStr);
    const today = new Date();
    const diffTime = expirationDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays <= days;
  }
  
  getDaysDifference(dateStr: string | Date | undefined): number {
    if (!dateStr) return 0;
    
    const expirationDate = new Date(dateStr);
    const today = new Date();
    const diffTime = expirationDate.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }
}