import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { DataTableComponent, TableColumn } from '../../shared/components/data-table/data-table.component';
import { CardComponent } from '../../shared/components/card/card.component';
import { UserService } from '../../core/services/user.service';
import { User, UserRole, UserStatus } from '../../shared/models/user.model';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    PageHeaderComponent,
    DataTableComponent,
    CardComponent
  ],
  template: `
    <div class="users-page">
      <app-page-header title="Users" subtitle="Manage user accounts">
        <button class="btn btn-primary" (click)="showAddUserForm = true">
          <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20" fill="currentColor">
            <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z"/>
          </svg>
          Add User
        </button>
      </app-page-header>
      
      <app-card *ngIf="showAddUserForm" title="Add New User" class="mb-3">
        <form class="add-user-form" (submit)="$event.preventDefault(); addUser()">
          <div class="form-row">
            <div class="form-group">
              <label for="name" class="form-label">Name</label>
              <input
                type="text"
                id="name"
                class="form-control"
                [(ngModel)]="newUser.name"
                name="name"
                required
              />
            </div>
            
            <div class="form-group">
              <label for="email" class="form-label">Email</label>
              <input
                type="email"
                id="email"
                class="form-control"
                [(ngModel)]="newUser.email"
                name="email"
                required
              />
            </div>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label for="role" class="form-label">Role</label>
              <select
                id="role"
                class="form-control"
                [(ngModel)]="newUser.role"
                name="role"
                required
              >
                <option [value]="UserRole.ADMIN">Admin</option>
                <option [value]="UserRole.MANAGER">Manager</option>
                <option [value]="UserRole.EMPLOYEE">Employee</option>
                <option [value]="UserRole.VIEWER">Viewer</option>
              </select>
            </div>
            
            <div class="form-group">
              <label for="status" class="form-label">Status</label>
              <select
                id="status"
                class="form-control"
                [(ngModel)]="newUser.status"
                name="status"
                required
              >
                <option [value]="UserStatus.ACTIVE">Active</option>
                <option [value]="UserStatus.INACTIVE">Inactive</option>
              </select>
            </div>
          </div>
          
          <div class="form-actions">
            <button type="button" class="btn btn-secondary" (click)="showAddUserForm = false">
              Cancel
            </button>
            <button type="submit" class="btn btn-primary">
              Add User
            </button>
          </div>
        </form>
      </app-card>
      
      <app-card *ngIf="selectedUser" [title]="'Edit User: ' + selectedUser.name" class="mb-3">
        <form class="edit-user-form" (submit)="$event.preventDefault(); updateUser()">
          <div class="form-row">
            <div class="form-group">
              <label for="edit-name" class="form-label">Name</label>
              <input
                type="text"
                id="edit-name"
                class="form-control"
                [(ngModel)]="selectedUser.name"
                name="name"
                required
              />
            </div>
            
            <div class="form-group">
              <label for="edit-email" class="form-label">Email</label>
              <input
                type="email"
                id="edit-email"
                class="form-control"
                [(ngModel)]="selectedUser.email"
                name="email"
                required
              />
            </div>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label for="edit-role" class="form-label">Role</label>
              <select
                id="edit-role"
                class="form-control"
                [(ngModel)]="selectedUser.role"
                name="role"
                required
              >
                <option [value]="UserRole.ADMIN">Admin</option>
                <option [value]="UserRole.MANAGER">Manager</option>
                <option [value]="UserRole.EMPLOYEE">Employee</option>
                <option [value]="UserRole.VIEWER">Viewer</option>
              </select>
            </div>
            
            <div class="form-group">
              <label for="edit-status" class="form-label">Status</label>
              <select
                id="edit-status"
                class="form-control"
                [(ngModel)]="selectedUser.status"
                name="status"
                required
              >
                <option [value]="UserStatus.ACTIVE">Active</option>
                <option [value]="UserStatus.INACTIVE">Inactive</option>
                <option [value]="UserStatus.SUSPENDED">Suspended</option>
              </select>
            </div>
          </div>
          
          <div class="user-permissions" *ngIf="permissions.length > 0">
            <h4>Permissions</h4>
            <div class="permissions-list">
              <div class="permission-group" *ngFor="let group of groupedPermissions | keyvalue">
                <h5>{{ group.key }}</h5>
                <div class="permission-items">
                  <div class="permission-item" *ngFor="let permission of group.value">
                    <label class="checkbox-container">
                      <input type="checkbox" [checked]="isPermissionSelected(permission.id)" (change)="togglePermission(permission.id)" />
                      <span class="checkbox-label">{{ permission.name }}</span>
                      <small>{{ permission.description }}</small>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="form-actions">
            <button type="button" class="btn btn-secondary" (click)="selectedUser = null">
              Cancel
            </button>
            <button type="submit" class="btn btn-primary">
              Update User
            </button>
          </div>
        </form>
      </app-card>
      
      <app-card>
        <app-data-table
          [columns]="columns"
          [data]="users"
          [showSearch]="true"
          [showActions]="true"
          [showPagination]="true"
          (rowClick)="onUserSelect($event)"
          (edit)="onUserSelect($event)"
          (delete)="onUserDelete($event)"
        >
          <div tableActions>
            <div class="filter-dropdown">
              <select class="form-control" [(ngModel)]="statusFilter" (change)="applyFilters()">
                <option value="all">All Statuses</option>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
                <option value="SUSPENDED">Suspended</option>
              </select>
            </div>
            <div class="filter-dropdown">
              <select class="form-control" [(ngModel)]="roleFilter" (change)="applyFilters()">
                <option value="all">All Roles</option>
                <option value="ADMIN">Admin</option>
                <option value="MANAGER">Manager</option>
                <option value="EMPLOYEE">Employee</option>
                <option value="VIEWER">Viewer</option>
              </select>
            </div>
          </div>
        </app-data-table>
      </app-card>
      
      <div class="confirm-dialog" *ngIf="showDeleteConfirm">
        <div class="confirm-dialog-content">
          <h3>Confirm Delete</h3>
          <p>Are you sure you want to delete the user "{{ userToDelete?.name }}"?</p>
          <p>This action cannot be undone.</p>
          <div class="confirm-actions">
            <button class="btn btn-secondary" (click)="showDeleteConfirm = false">Cancel</button>
            <button class="btn btn-error" (click)="confirmDelete()">Delete</button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .users-page {
      padding: var(--spacing-3);
    }
    
    .form-row {
      display: flex;
      gap: var(--spacing-3);
      margin-bottom: var(--spacing-2);
    }
    
    .form-group {
      flex: 1;
    }
    
    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: var(--spacing-2);
      margin-top: var(--spacing-3);
    }
    
    .filter-dropdown {
      width: 150px;
    }
    
    .filter-dropdown select {
      font-size: 0.875rem;
      padding: 4px 8px;
    }
    
    .user-permissions {
      margin-top: var(--spacing-3);
      border-top: 1px solid var(--neutral-200);
      padding-top: var(--spacing-3);
    }
    
    .user-permissions h4 {
      margin-bottom: var(--spacing-2);
    }
    
    .permissions-list {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: var(--spacing-3);
    }
    
    .permission-group h5 {
      margin-bottom: var(--spacing-1);
      color: var(--neutral-800);
      font-size: 0.9rem;
    }
    
    .permission-items {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-1);
    }
    
    .permission-item {
      display: flex;
      align-items: flex-start;
    }
    
    .checkbox-container {
      display: flex;
      flex-direction: column;
      cursor: pointer;
    }
    
    .checkbox-label {
      margin-left: var(--spacing-1);
      font-weight: 500;
    }
    
    .checkbox-container small {
      margin-left: calc(var(--spacing-1) + 16px);
      color: var(--neutral-600);
      font-size: 0.75rem;
    }
    
    .confirm-dialog {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }
    
    .confirm-dialog-content {
      background-color: white;
      border-radius: var(--radius-md);
      padding: var(--spacing-3);
      width: 400px;
      max-width: 90%;
      box-shadow: var(--shadow-lg);
    }
    
    .confirm-dialog h3 {
      margin-top: 0;
      margin-bottom: var(--spacing-2);
      color: var(--error);
    }
    
    .confirm-actions {
      display: flex;
      justify-content: flex-end;
      gap: var(--spacing-2);
      margin-top: var(--spacing-3);
    }
    
    @media (max-width: 768px) {
      .form-row {
        flex-direction: column;
        gap: var(--spacing-2);
      }
      
      .permissions-list {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class UsersComponent {
  columns: TableColumn[] = [
    { key: 'avatar', title: 'Avatar', type: 'image', width: '60px' },
    { key: 'name', title: 'Name', sortable: true },
    { key: 'email', title: 'Email', sortable: true },
    { key: 'role', title: 'Role', sortable: true },
    { key: 'status', title: 'Status', type: 'status', sortable: true },
    { key: 'lastLogin', title: 'Last Login', type: 'date', sortable: true }
  ];
  
  users: User[] = [];
  allUsers: User[] = [];
  permissions: any[] = [];
  selectedPermissions: string[] = [];
  
  selectedUser: User | null = null;
  userToDelete: User | null = null;
  showDeleteConfirm = false;
  showAddUserForm = false;
  
  newUser = {
    name: '',
    email: '',
    role: UserRole.EMPLOYEE,
    status: UserStatus.ACTIVE
  };
  
  statusFilter = 'all';
  roleFilter = 'all';
  
  // Enum made available to template
  UserRole = UserRole;
  UserStatus = UserStatus;
  
  constructor(private userService: UserService) {
    this.loadData();
  }
  
  loadData(): void {
    this.allUsers = this.userService.users;
    this.users = [...this.allUsers];
    this.permissions = this.userService.permissions;
  }
  
  get groupedPermissions(): {[key: string]: any[]} {
    const grouped: {[key: string]: any[]} = {};
    
    this.permissions.forEach(permission => {
      if (!grouped[permission.module]) {
        grouped[permission.module] = [];
      }
      
      grouped[permission.module].push(permission);
    });
    
    return grouped;
  }
  
  applyFilters(): void {
    let filtered = [...this.allUsers];
    
    if (this.statusFilter !== 'all') {
      filtered = filtered.filter(user => user.status === this.statusFilter);
    }
    
    if (this.roleFilter !== 'all') {
      filtered = filtered.filter(user => user.role === this.roleFilter);
    }
    
    this.users = filtered;
  }
  
  onUserSelect(user: User): void {
    this.selectedUser = { ...user };
    
    // For demo, we'll simulate that admins have all permissions
    // and managers have view permissions
    this.selectedPermissions = [];
    
    if (user.role === UserRole.ADMIN) {
      this.selectedPermissions = this.permissions.map(p => p.id);
    } else if (user.role === UserRole.MANAGER) {
      this.selectedPermissions = this.permissions
        .filter(p => p.name.startsWith('view_'))
        .map(p => p.id);
    }
  }
  
  onUserDelete(user: User): void {
    this.userToDelete = user;
    this.showDeleteConfirm = true;
  }
  
  confirmDelete(): void {
    if (this.userToDelete) {
      this.userService.deleteUser(this.userToDelete.id);
      this.showDeleteConfirm = false;
      this.userToDelete = null;
      this.loadData();
    }
  }
  
  addUser(): void {
    this.userService.createUser({
      ...this.newUser,
      lastLogin: new Date()
    });
    
    // Reset form
    this.newUser = {
      name: '',
      email: '',
      role: UserRole.EMPLOYEE,
      status: UserStatus.ACTIVE
    };
    
    this.showAddUserForm = false;
    this.loadData();
  }
  
  updateUser(): void {
    if (this.selectedUser) {
      this.userService.updateUserRole(this.selectedUser.id, this.selectedUser.role);
      this.userService.updateUserStatus(this.selectedUser.id, this.selectedUser.status);
      this.selectedUser = null;
      this.loadData();
    }
  }
  
  isPermissionSelected(permissionId: string): boolean {
    return this.selectedPermissions.includes(permissionId);
  }
  
  togglePermission(permissionId: string): void {
    if (this.selectedPermissions.includes(permissionId)) {
      this.selectedPermissions = this.selectedPermissions.filter(id => id !== permissionId);
    } else {
      this.selectedPermissions.push(permissionId);
    }
  }
}