import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { CardComponent } from '../../shared/components/card/card.component';
import { DataTableComponent, TableColumn } from '../../shared/components/data-table/data-table.component';
import { ProductService } from '../../core/services/product.service';
import { Product, ProductStatus } from '../../shared/models/product.model';

@Component({
  selector: 'app-products',
  imports: [
    CommonModule,
    FormsModule,
    PageHeaderComponent,
    CardComponent,
    DataTableComponent
  ],

  template: `
    <div class="products-page">
      <app-page-header title="Products" subtitle="View and manage products">
        <button class="btn btn-primary">
          <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20" fill="currentColor">
            <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z"/>
          </svg>
          Add Product
        </button>
      </app-page-header>
      
      <div class="tabs">
        <button 
          class="tab-button" 
          [class.active]="activeTab === 'all'" 
          (click)="setActiveTab('all')"
        >
          All Products
        </button>
        <button 
          class="tab-button" 
          [class.active]="activeTab === 'expiring'" 
          (click)="setActiveTab('expiring')"
        >
          Expiring Soon
        </button>
        <button 
          class="tab-button" 
          [class.active]="activeTab === 'out-of-stock'" 
          (click)="setActiveTab('out-of-stock')"
        >
          Out of Stock
        </button>
      </div>
      
      <app-card>
        <app-data-table
          [columns]="columns"
          [data]="filteredProducts"
          [showSearch]="true"
          [showActions]="true"
          [showPagination]="true"
          (rowClick)="viewProductDetails($event)"
          (edit)="editProduct($event)"
          (delete)="deleteProduct($event)"
        >
          <div tableActions>
            <div class="filter-dropdown">
              <select class="form-control" [(ngModel)]="categoryFilter" (change)="applyFilters()">
                <option value="all">All Categories</option>
                <option *ngFor="let category of uniqueCategories" [value]="category">{{ category }}</option>
              </select>
            </div>
          </div>
        </app-data-table>
      </app-card>
      
      <app-card *ngIf="selectedProduct" [title]="'Product Details: ' + selectedProduct.name" class="mt-3">
        <div class="product-details">
          <div class="product-header">
            <div class="product-image">
              <img [src]="selectedProduct.image || 'https://via.placeholder.com/200x200'" alt="{{ selectedProduct.name }}" />
            </div>
            <div class="product-info">
              <h3 class="product-name">{{ selectedProduct.name }}</h3>
              <p class="product-category">{{ selectedProduct.category }}</p>
              <div class="product-price-info">
                <div class="price-item">
                  <span class="price-label">Price:</span>
                  <span class="price-value">{{ selectedProduct.price | number:'1.2-2' }}</span>
                </div>
                <div class="price-item">
                  <span class="price-label">Cost:</span>
                  <span class="price-value">{{ selectedProduct.cost | number:'1.2-2' }}</span>
                </div>
                <div class="price-item">
                  <span class="price-label">Margin:</span>
                  <span class="price-value">{{ calculateMargin(selectedProduct) }}%</span>
                </div>
              </div>
              <div class="product-status">
                <span class="status-label">Status:</span>
                <span class="status-badge" [class]="'status-' + selectedProduct.status.toLowerCase()">
                  {{ formatStatus(selectedProduct.status) }}
                </span>
              </div>
              <div class="product-stock">
                <span class="stock-label">Stock:</span>
                <span class="stock-value" [class.low-stock]="selectedProduct.stockQuantity < 10">
                  {{ selectedProduct.stockQuantity }} units
                </span>
              </div>
              <div class="product-expires" *ngIf="selectedProduct.expirationDate">
                <span class="expires-label">Expires:</span>
                <span 
                  class="expires-value"
                  [class.expiring-soon]="isDaysDifference(selectedProduct.expirationDate, 7)"
                  [class.expiring-warning]="isDaysDifference(selectedProduct.expirationDate, 14) && !isDaysDifference(selectedProduct.expirationDate, 7)"
                >
                  {{ selectedProduct.expirationDate | date:'MMM d, y' }}
                  <span *ngIf="isDaysDifference(selectedProduct.expirationDate, 14)">({{ getDaysDifference(selectedProduct.expirationDate) }} days)</span>
                </span>
              </div>
            </div>
          </div>
          
          <div class="product-description">
            <h4>Description</h4>
            <p>{{ selectedProduct.description }}</p>
          </div>
          
          <div class="product-actions">
            <button class="btn btn-secondary" (click)="selectedProduct = null">Close</button>
            <button class="btn btn-primary">Edit Product</button>
          </div>
        </div>
      </app-card>
    </div>
  `,
  styles: [`
    .products-page {
      padding: var(--spacing-3);
    }
    
    .tabs {
      display: flex;
      margin-bottom: var(--spacing-3);
      border-bottom: 1px solid var(--neutral-200);
    }
    
    .tab-button {
      padding: var(--spacing-2) var(--spacing-3);
      background: none;
      border: none;
      border-bottom: 2px solid transparent;
      cursor: pointer;
      font-weight: 500;
      color: var(--neutral-700);
      transition: all var(--transition-fast);
    }
    
    .tab-button:hover {
      color: var(--primary-600);
    }
    
    .tab-button.active {
      color: var(--primary-600);
      border-bottom-color: var(--primary-600);
    }
    
    .filter-dropdown {
      width: 200px;
    }
    
    .mt-3 {
      margin-top: var(--spacing-3);
    }
    
    .product-details {
      padding: var(--spacing-1);
    }
    
    .product-header {
      display: flex;
      gap: var(--spacing-3);
      margin-bottom: var(--spacing-3);
      padding-bottom: var(--spacing-3);
      border-bottom: 1px solid var(--neutral-200);
    }
    
    .product-image {
      width: 200px;
      height: 200px;
      flex-shrink: 0;
    }
    
    .product-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: var(--radius-md);
    }
    
    .product-info {
      flex: 1;
    }
    
    .product-name {
      margin: 0 0 var(--spacing-1) 0;
      font-size: 1.5rem;
    }
    
    .product-category {
      margin: 0 0 var(--spacing-2) 0;
      color: var(--neutral-600);
    }
    
    .product-price-info {
      display: flex;
      gap: var(--spacing-3);
      margin-bottom: var(--spacing-2);
    }
    
    .price-item {
      display: flex;
      flex-direction: column;
    }
    
    .price-label, .status-label, .stock-label, .expires-label {
      font-size: 0.875rem;
      color: var(--neutral-600);
    }
    
    .price-value {
      font-size: 1.25rem;
      font-weight: 500;
    }
    
    .product-status, .product-stock, .product-expires {
      margin-bottom: var(--spacing-1);
    }
    
    .low-stock {
      color: var(--warning);
      font-weight: 500;
    }
    
    .expiring-soon {
      color: var(--error);
      font-weight: 500;
    }
    
    .expiring-warning {
      color: var(--warning);
    }
    
    .product-description {
      margin-bottom: var(--spacing-3);
    }
    
    .product-description h4 {
      margin-bottom: var(--spacing-1);
    }
    
    .product-actions {
      display: flex;
      justify-content: flex-end;
      gap: var(--spacing-2);
      margin-top: var(--spacing-3);
      padding-top: var(--spacing-3);
      border-top: 1px solid var(--neutral-200);
    }
    
    @media (max-width: 768px) {
      .product-header {
        flex-direction: column;
      }
      
      .product-image {
        width: 100%;
        height: auto;
        max-height: 300px;
        margin-bottom: var(--spacing-2);
      }
      
      .tabs {
        overflow-x: auto;
        padding-bottom: var(--spacing-1);
      }
      
      .tab-button {
        white-space: nowrap;
        flex-shrink: 0;
      }
    }
  `]
})
export class ProductsComponent {
  columns: TableColumn[] = [
    { key: 'image', title: 'Image', type: 'image', width: '60px' },
    { key: 'name', title: 'Product Name', sortable: true },
    { key: 'category', title: 'Category', sortable: true },
    { key: 'price', title: 'Price', type: 'currency', sortable: true },
    { key: 'stockQuantity', title: 'Stock', sortable: true },
    { key: 'expirationDate', title: 'Expires', type: 'date', sortable: true },
    { key: 'status', title: 'Status', type: 'status', sortable: true }
  ];
  
  allProducts: Product[] = [];
  filteredProducts: Product[] = [];
  selectedProduct: Product | null = null;
  
  activeTab: 'all' | 'expiring' | 'out-of-stock' = 'all';
  categoryFilter = 'all';
  
  constructor(private productService: ProductService) {
    this.loadProducts();
  }
  
  loadProducts(): void {
    this.allProducts = this.productService.products;
    this.applyFilters();
  }
  
  get uniqueCategories(): string[] {
    const categories = new Set<string>();
    this.allProducts.forEach(product => categories.add(product.category));
    return Array.from(categories);
  }
  
  setActiveTab(tab: 'all' | 'expiring' | 'out-of-stock'): void {
    this.activeTab = tab;
    this.applyFilters();
  }
  
  applyFilters(): void {
    let filtered = [...this.allProducts];
    
    // Apply tab filter
    if (this.activeTab === 'expiring') {
      filtered = this.productService.getExpiringProducts(30);
    } else if (this.activeTab === 'out-of-stock') {
      filtered = filtered.filter(product => product.status === ProductStatus.OUT_OF_STOCK);
    }
    
    // Apply category filter
    if (this.categoryFilter !== 'all') {
      filtered = filtered.filter(product => product.category === this.categoryFilter);
    }
    
    this.filteredProducts = filtered;
  }
  
  viewProductDetails(product: Product): void {
    this.selectedProduct = { ...product };
  }
  
  editProduct(product: Product): void {
    // This would typically open a form to edit the product
    console.log('Edit product:', product);
  }
  
  deleteProduct(product: Product): void {
    // This would typically show a confirmation dialog
    console.log('Delete product:', product);
  }
  
  calculateMargin(product: Product): number {
    if (product.cost === 0) return 0;
    const margin = ((product.price - product.cost) / product.price) * 100;
    return Math.round(margin);
  }
  
  formatStatus(status: string): string {
    return status.replace('_', ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
  }
  
  isDaysDifference(dateStr: string | Date | undefined, days: number): boolean {
    if (!dateStr) return false;
    
    const expirationDate = new Date(dateStr);
    const today = new Date();
    const diffTime = expirationDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays <= days;
  }
  
  getDaysDifference(dateStr: string | Date | undefined): number {
    if (!dateStr) return 0;
    
    const expirationDate = new Date(dateStr);
    const today = new Date();
    const diffTime = expirationDate.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }
}