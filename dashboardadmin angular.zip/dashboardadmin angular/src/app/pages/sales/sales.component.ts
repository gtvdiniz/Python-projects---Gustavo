import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { CardComponent } from '../../shared/components/card/card.component';
import { DateFilterComponent } from '../../shared/components/date-filter/date-filter.component';
import { DataTableComponent, TableColumn } from '../../shared/components/data-table/data-table.component';
import { ChartComponent } from '../../shared/components/chart/chart.component';
import { StatCardComponent } from '../../shared/components/stat-card/stat-card.component';
import { SalesService } from '../../core/services/sales.service';
import { Sale, SaleStatus } from '../../shared/models/sale.model';

@Component({
  selector: 'app-sales',
  standalone: true,
  imports: [
    CommonModule,
    PageHeaderComponent,
    CardComponent,
    DateFilterComponent,
    DataTableComponent,
    ChartComponent,
    StatCardComponent
  ],
  template: `
    <div class="sales-page">
      <app-page-header title="Sales" subtitle="View and manage sales information">
        <button class="btn btn-primary">
          <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20" fill="currentColor">
            <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z"/>
          </svg>
          New Sale
        </button>
      </app-page-header>
      
      <app-date-filter (filterChange)="onFilterChange($event)"></app-date-filter>
      
      <div class="sales-summary">
        <app-stat-card
          title="Total Revenue"
          [value]="'$' + salesSummary.totalRevenue.toFixed(2)"
          type="primary"
        ></app-stat-card>
        
        <app-stat-card
          title="Total Sales"
          [value]="salesSummary.totalSales.toString()"
          type="success"
        ></app-stat-card>
        
        <app-stat-card
          title="Average Order Value"
          [value]="'$' + salesSummary.averageOrderValue.toFixed(2)"
          type="info"
        ></app-stat-card>
      </div>
      
      <div class="sales-charts">
        <app-card title="Revenue by Date" class="chart-card">
          <app-chart [type]="'line'" [data]="salesChartData"></app-chart>
        </app-card>
        
        <app-card title="Sales by Payment Method" class="chart-card">
          <app-chart [type]="'doughnut'" [data]="paymentChartData"></app-chart>
        </app-card>
      </div>
      
      <app-card title="Sales List" class="mb-3">
        <app-data-table
          [columns]="columns"
          [data]="sales"
          [showSearch]="true"
          [showActions]="true"
          [showPagination]="true"
          (rowClick)="viewSaleDetails($event)"
          (edit)="editSale($event)"
          (delete)="deleteSale($event)"
        ></app-data-table>
      </app-card>
      
      <app-card *ngIf="selectedSale" [title]="'Sale Details: #' + selectedSale.id">
        <div class="sale-details">
          <div class="sale-header">
            <div class="sale-info">
              <div class="info-group">
                <span class="info-label">Date:</span>
                <span class="info-value">{{ selectedSale.createdAt | date:'medium' }}</span>
              </div>
              <div class="info-group">
                <span class="info-label">Customer:</span>
                <span class="info-value">{{ selectedSale.customerName || 'Walk-in Customer' }}</span>
              </div>
              <div class="info-group">
                <span class="info-label">Status:</span>
                <span class="status-badge" [class]="'status-' + selectedSale.status.toLowerCase()">{{ selectedSale.status }}</span>
              </div>
            </div>
            <div class="sale-totals">
              <div class="total-item">
                <span class="total-label">Subtotal:</span>
                <span class="total-value">{{ (selectedSale.total - selectedSale.tax + selectedSale.discount).toFixed(2) }}</span>
              </div>
              <div class="total-item">
                <span class="total-label">Tax:</span>
                <span class="total-value">{{ selectedSale.tax.toFixed(2) }}</span>
              </div>
              <div class="total-item">
                <span class="total-label">Discount:</span>
                <span class="total-value">-{{ selectedSale.discount.toFixed(2) }}</span>
              </div>
              <div class="total-item total-final">
                <span class="total-label">Total:</span>
                <span class="total-value">{{ selectedSale.total.toFixed(2) }}</span>
              </div>
            </div>
          </div>
          
          <div class="sale-items">
            <h4>Items</h4>
            <div class="table-responsive">
              <table>
                <thead>
                  <tr>
                    <th>Product</th>
                    <th class="text-right">Quantity</th>
                    <th class="text-right">Unit Price</th>
                    <th class="text-right">Discount</th>
                    <th class="text-right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let item of selectedSale.items">
                    <td>{{ item.productName }}</td>
                    <td class="text-right">{{ item.quantity }}</td>
                    <td class="text-right">{{ item.unitPrice.toFixed(2) }}</td>
                    <td class="text-right">{{ item.discount.toFixed(2) }}</td>
                    <td class="text-right">{{ item.total.toFixed(2) }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <div class="sale-actions">
            <button class="btn btn-secondary" (click)="selectedSale = null">Close</button>
            <button class="btn btn-primary">Print Receipt</button>
          </div>
        </div>
      </app-card>
    </div>
  `,
  styles: [`
    .sales-page {
      padding: var(--spacing-3);
    }
    
    .sales-summary {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: var(--spacing-3);
      margin-bottom: var(--spacing-3);
    }
    
    .sales-charts {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
      gap: var(--spacing-3);
      margin-bottom: var(--spacing-3);
    }
    
    .chart-card {
      height: 350px;
    }
    
    .mb-3 {
      margin-bottom: var(--spacing-3);
    }
    
    .sale-details {
      padding: var(--spacing-1);
    }
    
    .sale-header {
      display: flex;
      justify-content: space-between;
      margin-bottom: var(--spacing-3);
      padding-bottom: var(--spacing-2);
      border-bottom: 1px solid var(--neutral-200);
    }
    
    .sale-info {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-1);
    }
    
    .info-group {
      display: flex;
      align-items: center;
    }
    
    .info-label {
      font-weight: 500;
      margin-right: var(--spacing-1);
      min-width: 80px;
    }
    
    .sale-totals {
      text-align: right;
    }
    
    .total-item {
      margin-bottom: var(--spacing-1);
    }
    
    .total-label {
      font-weight: 500;
      margin-right: var(--spacing-1);
    }
    
    .total-final {
      font-size: 1.25rem;
      font-weight: 600;
      margin-top: var(--spacing-2);
      padding-top: var(--spacing-1);
      border-top: 1px solid var(--neutral-200);
    }
    
    .sale-items {
      margin-bottom: var(--spacing-3);
    }
    
    .sale-items h4 {
      margin-bottom: var(--spacing-2);
    }
    
    .sale-actions {
      display: flex;
      justify-content: flex-end;
      gap: var(--spacing-2);
      margin-top: var(--spacing-3);
      padding-top: var(--spacing-2);
      border-top: 1px solid var(--neutral-200);
    }
    
    .text-right {
      text-align: right;
    }
    
    @media (max-width: 768px) {
      .sale-header {
        flex-direction: column;
        gap: var(--spacing-2);
      }
      
      .sale-totals {
        text-align: left;
        border-top: 1px solid var(--neutral-200);
        padding-top: var(--spacing-2);
      }
    }
  `]
})
export class SalesComponent {
  selectedSale: any;
  columns: TableColumn[] = [
    { key: 'id', title: 'Order #', sortable: true },
    { key: 'customerName', title: 'Customer' },
    { key: 'createdAt', title: 'Date', type: 'date', sortable: true },
    { key: 'total', title: 'Total', type: 'currency', sortable: true },
    { key: 'paymentMethod', title: 'Payment Method' },
    { key: 'status', title: 'Status', type: 'status', sortable: true }
  ];
  
  sales: Sale[] = [];
  currentFilterType: string = 'month';
  currentStartDate?: Date;
  currentEndDate?: Date;
  
  salesSummary = {
    totalSales: 0,
    totalRevenue: 0,
    averageOrderValue: 0,
    period: ''
  };
  
  salesChartData: any = {
    labels: [],
    datasets: []
  };
  
  paymentChartData: any = {
    labels: [],
    datasets: []
  };
  
  constructor(private salesService: SalesService) {
    this.loadSalesData('month');
  }
  
  onFilterChange(filter: {type: string, startDate?: Date, endDate?: Date}): void {
    this.currentFilterType = filter.type;
    this.currentStartDate = filter.startDate;
    this.currentEndDate = filter.endDate;
    
    this.loadSalesData(filter.type, filter.startDate, filter.endDate);
  }
  
  loadSalesData(filterType: string, startDate?: Date, endDate?: Date): void {
    let filteredSales: Sale[] = [];
    
    // Get sales based on filter
    if (filterType === 'day') {
      filteredSales = this.salesService.getSalesByDay(new Date());
    } else if (filterType === 'week') {
      filteredSales = this.salesService.getSalesByWeek(new Date());
    } else if (filterType === 'month') {
      filteredSales = this.salesService.getSalesByMonth(new Date());
    } else if (filterType === 'year') {
      filteredSales = this.salesService.getSalesByYear(new Date());
    } else if (filterType === 'custom' && startDate && endDate) {
      filteredSales = this.salesService.filterSalesByDateRange(startDate, endDate);
    }
    
    this.sales = filteredSales;
    this.salesSummary = this.salesService.getSalesSummary(filteredSales);
    
    // Update charts
    this.updateCharts(filteredSales, filterType);
  }
  
  updateCharts(sales: Sale[], filterType: string): void {
    // Prepare sales chart data
    this.prepareSalesChart(sales, filterType);
    
    // Prepare payment method chart
    this.preparePaymentMethodChart(sales);
  }
  
  prepareSalesChart(sales: Sale[], filterType: string): void {
    let labels: string[] = [];
    let revenues: number[] = [];
    
    // Group sales by date
    const salesByDate = new Map<string, number>();
    
    if (filterType === 'day') {
      // Group by hour for day view
      for (let i = 0; i < 24; i++) {
        const hourLabel = `${i}:00`;
        salesByDate.set(hourLabel, 0);
      }
      
      sales.forEach(sale => {
        const date = new Date(sale.createdAt);
        const hourLabel = `${date.getHours()}:00`;
        salesByDate.set(hourLabel, (salesByDate.get(hourLabel) || 0) + sale.total);
      });
    } else if (filterType === 'week') {
      // Group by day for week view
      const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      daysOfWeek.forEach(day => salesByDate.set(day, 0));
      
      sales.forEach(sale => {
        const date = new Date(sale.createdAt);
        const dayLabel = daysOfWeek[date.getDay()];
        salesByDate.set(dayLabel, (salesByDate.get(dayLabel) || 0) + sale.total);
      });
    } else if (filterType === 'month') {
      // Group by day for month view
      const today = new Date();
      const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
      
      for (let i = 1; i <= daysInMonth; i++) {
        salesByDate.set(`${i}`, 0);
      }
      
      sales.forEach(sale => {
        const date = new Date(sale.createdAt);
        const dayLabel = `${date.getDate()}`;
        salesByDate.set(dayLabel, (salesByDate.get(dayLabel) || 0) + sale.total);
      });
    } else if (filterType === 'year') {
      // Group by month for year view
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      months.forEach(month => salesByDate.set(month, 0));
      
      sales.forEach(sale => {
        const date = new Date(sale.createdAt);
        const monthLabel = months[date.getMonth()];
        salesByDate.set(monthLabel, (salesByDate.get(monthLabel) || 0) + sale.total);
      });
    } else if (filterType === 'custom') {
      // For custom, group by day
      const dateMap = new Map<string, number>();
      
      sales.forEach(sale => {
        const date = new Date(sale.createdAt);
        const dateStr = date.toISOString().split('T')[0];
        dateMap.set(dateStr, (dateMap.get(dateStr) || 0) + sale.total);
      });
      
      // Sort dates
      const sortedDates = Array.from(dateMap.keys()).sort();
      
      sortedDates.forEach(dateStr => {
        const date = new Date(dateStr);
        labels.push(date.toLocaleDateString());
        revenues.push(dateMap.get(dateStr) || 0);
      });
    }
    
    // Convert map to arrays if not custom
    if (filterType !== 'custom') {
      labels = Array.from(salesByDate.keys());
      revenues = Array.from(salesByDate.values());
    }
    
    // Create chart data
    this.salesChartData = {
      labels,
      datasets: [
        {
          label: 'Revenue',
          data: revenues,
          borderColor: '#607D2F',
          backgroundColor: 'rgba(96, 125, 47, 0.1)',
          fill: true,
          tension: 0.4
        }
      ]
    };
  }
  
  preparePaymentMethodChart(sales: Sale[]): void {
    // Count sales by payment method
    const paymentCounts = new Map<string, number>();
    
    sales.forEach(sale => {
      paymentCounts.set(sale.paymentMethod, (paymentCounts.get(sale.paymentMethod) || 0) + 1);
    });
    
    // Create chart data
    this.paymentChartData = {
      labels: Array.from(paymentCounts.keys()).map(this.formatPaymentMethod),
      datasets: [
        {
          data: Array.from(paymentCounts.values()),
          backgroundColor: [
            '#607D2F',  // Primary
            '#84AD33',  // Primary lighter
            '#A6CA59',  // Primary lightest
            '#4CAF50',  // Success
            '#9E9E9E'   // Neutral
          ],
          borderWidth: 1
        }
      ]
    };
  }
  
  formatPaymentMethod(method: string): string {
    return method.replace('_', ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
  }
  
  viewSaleDetails(sale: Sale): void {
    this.selectedSale = { ...sale };
  }
  
  editSale(sale: Sale): void {
    // This would typically open a form to edit the sale
    console.log('Edit sale:', sale);
  }
  
  deleteSale(sale: Sale): void {
    // This would typically show a confirmation dialog
    console.log('Delete sale:', sale);
  }
}