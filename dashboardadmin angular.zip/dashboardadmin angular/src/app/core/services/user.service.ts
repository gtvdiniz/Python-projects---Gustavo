import { Injectable, signal } from '@angular/core';
import { User, UserRole, UserStatus, UserPermission } from '../../shared/models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private usersSignal = signal<User[]>([]);
  private permissionsSignal = signal<UserPermission[]>([]);
  
  constructor() {
    // Initialize with mock data
    this.initMockData();
  }
  
  get users() {
    return this.usersSignal();
  }
  
  get permissions() {
    return this.permissionsSignal();
  }
  
  getActiveUsers(): User[] {
    return this.usersSignal().filter(user => user.status === UserStatus.ACTIVE);
  }
  
  getUserById(id: string): User | undefined {
    return this.usersSignal().find(user => user.id === id);
  }
  
  searchUsers(query: string): User[] {
    const lowerQuery = query.toLowerCase();
    return this.usersSignal().filter(user => 
      user.name.toLowerCase().includes(lowerQuery) || 
      user.email.toLowerCase().includes(lowerQuery)
    );
  }
  
  updateUserRole(userId: string, role: UserRole): void {
    const users = [...this.usersSignal()];
    const index = users.findIndex(u => u.id === userId);
    
    if (index !== -1) {
      users[index] = {
        ...users[index],
        role,
        updatedAt: new Date()
      };
      
      this.usersSignal.set(users);
    }
  }
  
  updateUserStatus(userId: string, status: UserStatus): void {
    const users = [...this.usersSignal()];
    const index = users.findIndex(u => u.id === userId);
    
    if (index !== -1) {
      users[index] = {
        ...users[index],
        status,
        updatedAt: new Date()
      };
      
      this.usersSignal.set(users);
    }
  }
  
  createUser(user: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): void {
    const newUser: User = {
      ...user,
      id: crypto.randomUUID(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.usersSignal.update(users => [...users, newUser]);
  }
  
  deleteUser(userId: string): void {
    this.usersSignal.update(users => users.filter(u => u.id !== userId));
  }
  
  private initMockData(): void {
    // Mock users
    const mockUsers: User[] = [
      {
        id: '1',
        name: 'Admin User',
        email: 'admin@example.com',
        role: UserRole.ADMIN,
        status: UserStatus.ACTIVE,
        lastLogin: new Date(),
        createdAt: new Date(2023, 0, 15),
        updatedAt: new Date(2023, 0, 15),
        avatar: 'https://i.pravatar.cc/150?img=1'
      },
      {
        id: '2',
        name: 'Manager User',
        email: 'manager@example.com',
        role: UserRole.MANAGER,
        status: UserStatus.ACTIVE,
        lastLogin: new Date(2023, 4, 20),
        createdAt: new Date(2023, 1, 10),
        updatedAt: new Date(2023, 1, 10),
        avatar: 'https://i.pravatar.cc/150?img=2'
      },
      {
        id: '3',
        name: 'Employee One',
        email: 'employee1@example.com',
        role: UserRole.EMPLOYEE,
        status: UserStatus.ACTIVE,
        lastLogin: new Date(2023, 4, 25),
        createdAt: new Date(2023, 2, 5),
        updatedAt: new Date(2023, 2, 5),
        avatar: 'https://i.pravatar.cc/150?img=3'
      },
      {
        id: '4',
        name: 'Employee Two',
        email: 'employee2@example.com',
        role: UserRole.EMPLOYEE,
        status: UserStatus.INACTIVE,
        lastLogin: new Date(2023, 3, 10),
        createdAt: new Date(2023, 2, 20),
        updatedAt: new Date(2023, 3, 15),
        avatar: 'https://i.pravatar.cc/150?img=4'
      },
      {
        id: '5',
        name: 'Viewer User',
        email: 'viewer@example.com',
        role: UserRole.VIEWER,
        status: UserStatus.ACTIVE,
        lastLogin: new Date(2023, 4, 28),
        createdAt: new Date(2023, 3, 1),
        updatedAt: new Date(2023, 3, 1),
        avatar: 'https://i.pravatar.cc/150?img=5'
      },
      {
        id: '6',
        name: 'Suspended User',
        email: 'suspended@example.com',
        role: UserRole.EMPLOYEE,
        status: UserStatus.SUSPENDED,
        lastLogin: new Date(2023, 2, 15),
        createdAt: new Date(2023, 1, 5),
        updatedAt: new Date(2023, 3, 20),
        avatar: 'https://i.pravatar.cc/150?img=6'
      }
    ];
    
    // Mock permissions
    const mockPermissions: UserPermission[] = [
      { id: '1', name: 'view_dashboard', description: 'View Dashboard', module: 'Dashboard' },
      { id: '2', name: 'view_users', description: 'View Users', module: 'Users' },
      { id: '3', name: 'edit_users', description: 'Edit Users', module: 'Users' },
      { id: '4', name: 'delete_users', description: 'Delete Users', module: 'Users' },
      { id: '5', name: 'view_sales', description: 'View Sales', module: 'Sales' },
      { id: '6', name: 'create_sales', description: 'Create Sales', module: 'Sales' },
      { id: '7', name: 'view_products', description: 'View Products', module: 'Products' },
      { id: '8', name: 'edit_products', description: 'Edit Products', module: 'Products' },
      { id: '9', name: 'manage_permissions', description: 'Manage Permissions', module: 'Administration' }
    ];
    
    this.usersSignal.set(mockUsers);
    this.permissionsSignal.set(mockPermissions);
  }
}