import { Injectable, signal } from '@angular/core';
import { Sale, SaleStatus, PaymentMethod, SaleSummary } from '../../shared/models/sale.model';

@Injectable({
  providedIn: 'root'
})
export class SalesService {
  private salesSignal = signal<Sale[]>([]);
  
  constructor() {
    // Initialize with mock data
    this.initMockData();
  }
  
  get sales() {
    return this.salesSignal();
  }
  
  getSaleById(id: string): Sale | undefined {
    return this.salesSignal().find(sale => sale.id === id);
  }
  
  filterSalesByDateRange(startDate: Date, endDate: Date): Sale[] {
    return this.salesSignal().filter(sale => {
      const saleDate = new Date(sale.createdAt);
      return saleDate >= startDate && saleDate <= endDate;
    });
  }
  
  getSalesByDay(date: Date): Sale[] {
    const start = new Date(date);
    start.setHours(0, 0, 0, 0);
    
    const end = new Date(date);
    end.setHours(23, 59, 59, 999);
    
    return this.filterSalesByDateRange(start, end);
  }
  
  getSalesByWeek(date: Date): Sale[] {
    const start = new Date(date);
    start.setDate(start.getDate() - start.getDay()); // Start from Sunday
    start.setHours(0, 0, 0, 0);
    
    const end = new Date(start);
    end.setDate(end.getDate() + 6);
    end.setHours(23, 59, 59, 999);
    
    return this.filterSalesByDateRange(start, end);
  }
  
  getSalesByMonth(date: Date): Sale[] {
    const start = new Date(date.getFullYear(), date.getMonth(), 1);
    const end = new Date(date.getFullYear(), date.getMonth() + 1, 0, 23, 59, 59, 999);
    
    return this.filterSalesByDateRange(start, end);
  }
  
  getSalesByYear(date: Date): Sale[] {
    const start = new Date(date.getFullYear(), 0, 1);
    const end = new Date(date.getFullYear(), 11, 31, 23, 59, 59, 999);
    
    return this.filterSalesByDateRange(start, end);
  }
  
  getSalesSummary(sales: Sale[]): SaleSummary {
    if (sales.length === 0) {
      return {
        totalSales: 0,
        totalRevenue: 0,
        averageOrderValue: 0,
        period: 'No data'
      };
    }
    
    const totalSales = sales.length;
    const totalRevenue = sales.reduce((sum, sale) => sum + sale.total, 0);
    const averageOrderValue = totalRevenue / totalSales;
    
    return {
      totalSales,
      totalRevenue,
      averageOrderValue,
      period: `${sales.length} sales`
    };
  }
  
  private initMockData(): void {
    // Mock sales
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    const lastWeek = new Date(today);
    lastWeek.setDate(lastWeek.getDate() - 7);
    
    const lastMonth = new Date(today);
    lastMonth.setMonth(lastMonth.getMonth() - 1);
    
    const twoMonthsAgo = new Date(today);
    twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);
    
    const salesDates = [
      today,
      today,
      today,
      yesterday,
      yesterday,
      lastWeek,
      lastWeek,
      lastMonth,
      lastMonth,
      lastMonth,
      twoMonthsAgo,
      twoMonthsAgo
    ];
    
    const mockSales: Sale[] = salesDates.map((date, index) => {
      // Create some variability in the sales data
      const itemCount = Math.floor(Math.random() * 5) + 1;
      const items = Array.from({ length: itemCount }, (_, i) => ({
        id: `item-${index}-${i}`,
        productId: `${Math.floor(Math.random() * 10) + 1}`,
        productName: ['Organic Apples', 'Whole Wheat Bread', 'Organic Milk', 'Free Range Eggs', 'Premium Coffee Beans', 'Organic Bananas'][Math.floor(Math.random() * 6)],
        quantity: Math.floor(Math.random() * 5) + 1,
        unitPrice: parseFloat((Math.random() * 10 + 2).toFixed(2)),
        discount: parseFloat((Math.random() * 2).toFixed(2)),
        total: 0 // To be calculated
      }));
      
      // Calculate item totals
      items.forEach(item => {
        item.total = (item.quantity * item.unitPrice) - item.discount;
      });
      
      const subtotal = items.reduce((sum, item) => sum + item.total, 0);
      const tax = parseFloat((subtotal * 0.08).toFixed(2));
      const discount = parseFloat((Math.random() * 5).toFixed(2));
      const total = subtotal + tax - discount;
      
      return {
        id: `sale-${index + 1}`,
        customerId: Math.random() > 0.3 ? `customer-${Math.floor(Math.random() * 100) + 1}` : undefined,
        customerName: Math.random() > 0.3 ? ['John Doe', 'Jane Smith', 'Bob Johnson', 'Alice Williams', 'Carlos Rodriguez'][Math.floor(Math.random() * 5)] : undefined,
        total,
        tax,
        discount,
        paymentMethod: [PaymentMethod.CASH, PaymentMethod.CREDIT_CARD, PaymentMethod.DEBIT_CARD][Math.floor(Math.random() * 3)],
        status: SaleStatus.COMPLETED,
        items,
        createdAt: new Date(date),
        updatedAt: new Date(date),
        salesPerson: ['Admin User', 'Manager User', 'Employee One'][Math.floor(Math.random() * 3)]
      };
    });
    
    this.salesSignal.set(mockSales);
  }
}