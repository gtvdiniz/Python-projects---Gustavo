import { Injectable, signal } from '@angular/core';
import { User, UserRole } from '../../shared/models/user.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSignal = signal<User | null>(null);
  
  constructor() {
    // Mock user for demonstration
    this.setMockUser();
  }
  
  get currentUser() {
    return this.currentUserSignal();
  }
  
  get isLoggedIn(): boolean {
    return !!this.currentUserSignal();
  }
  
  get isAdmin(): boolean {
    return this.currentUserSignal()?.role === UserRole.ADMIN;
  }
  
  hasPermission(permission: string): boolean {
    // Mock implementation - in a real app, would check against user permissions
    const userRole = this.currentUserSignal()?.role;
    
    if (userRole === UserRole.ADMIN) {
      return true;
    }
    
    // Example permission check logic
    if (userRole === UserRole.MANAGER && 
        ['view_users', 'view_sales', 'view_products'].includes(permission)) {
      return true;
    }
    
    return false;
  }
  
  login(email: string, password: string): Promise<boolean> {
    // Mock implementation - in a real app, would validate against backend
    return new Promise((resolve) => {
      setTimeout(() => {
        if (email === 'admin@example.com' && password === 'password') {
          this.setMockUser();
          resolve(true);
        } else {
          resolve(false);
        }
      }, 800);
    });
  }
  
  logout(): void {
    this.currentUserSignal.set(null);
  }
  
  private setMockUser(): void {
    this.currentUserSignal.set({
      id: '1',
      name: 'Admin User',
      email: 'admin@example.com',
      role: UserRole.ADMIN,
      status: 'ACTIVE' as any,
      lastLogin: new Date(),
      createdAt: new Date(),
      updatedAt: new Date(),
      avatar: 'https://i.pravatar.cc/150?img=1'
    });
  }
}