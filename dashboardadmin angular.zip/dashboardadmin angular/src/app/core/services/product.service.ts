import { Injectable, signal } from '@angular/core';
import { Product, ProductStatus } from '../../shared/models/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private productsSignal = signal<Product[]>([]);
  
  constructor() {
    // Initialize with mock data
    this.initMockData();
  }
  
  get products() {
    return this.productsSignal();
  }
  
  getProductById(id: string): Product | undefined {
    return this.productsSignal().find(product => product.id === id);
  }
  
  getExpiringProducts(days: number = 30): Product[] {
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + days);
    
    return this.productsSignal().filter(product => {
      if (!product.expirationDate) return false;
      
      const expirationDate = new Date(product.expirationDate);
      return expirationDate <= futureDate && expirationDate >= today;
    }).sort((a, b) => {
      if (!a.expirationDate || !b.expirationDate) return 0;
      return new Date(a.expirationDate).getTime() - new Date(b.expirationDate).getTime();
    });
  }
  
  updateProductStock(productId: string, newQuantity: number): void {
    const products = [...this.productsSignal()];
    const index = products.findIndex(p => p.id === productId);
    
    if (index !== -1) {
      products[index] = {
        ...products[index],
        stockQuantity: newQuantity,
        status: newQuantity > 0 ? ProductStatus.ACTIVE : ProductStatus.OUT_OF_STOCK,
        updatedAt: new Date()
      };
      
      this.productsSignal.set(products);
    }
  }
  
  private initMockData(): void {
    // Generate dates for expiring products
    const today = new Date();
    
    const expirationDates = [
      new Date(today.getFullYear(), today.getMonth(), today.getDate() + 5),
      new Date(today.getFullYear(), today.getMonth(), today.getDate() + 10),
      new Date(today.getFullYear(), today.getMonth(), today.getDate() + 15),
      new Date(today.getFullYear(), today.getMonth(), today.getDate() + 20),
      new Date(today.getFullYear(), today.getMonth(), today.getDate() + 30),
      new Date(today.getFullYear(), today.getMonth(), today.getDate() + 45),
      new Date(today.getFullYear(), today.getMonth(), today.getDate() + 60)
    ];
    
    // Mock products
    const mockProducts: Product[] = [
      {
        id: '1',
        name: 'Organic Apples',
        description: 'Fresh organic apples from local farms',
        category: 'Fruits',
        price: 3.99,
        cost: 2.50,
        stockQuantity: 150,
        expirationDate: expirationDates[0],
        createdAt: new Date(2023, 0, 10),
        updatedAt: new Date(2023, 0, 10),
        status: ProductStatus.ACTIVE,
        image: 'https://images.pexels.com/photos/1510392/pexels-photo-1510392.jpeg?auto=compress&cs=tinysrgb&w=300'
      },
      {
        id: '2',
        name: 'Whole Wheat Bread',
        description: 'Freshly baked whole wheat bread',
        category: 'Bakery',
        price: 4.49,
        cost: 2.00,
        stockQuantity: 75,
        expirationDate: expirationDates[1],
        createdAt: new Date(2023, 0, 12),
        updatedAt: new Date(2023, 0, 12),
        status: ProductStatus.ACTIVE,
        image: 'https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=300'
      },
      {
        id: '3',
        name: 'Organic Milk',
        description: 'Organic whole milk from grass-fed cows',
        category: 'Dairy',
        price: 5.99,
        cost: 3.80,
        stockQuantity: 100,
        expirationDate: expirationDates[2],
        createdAt: new Date(2023, 0, 15),
        updatedAt: new Date(2023, 0, 15),
        status: ProductStatus.ACTIVE,
        image: 'https://images.pexels.com/photos/2505161/pexels-photo-2505161.jpeg?auto=compress&cs=tinysrgb&w=300'
      },
      {
        id: '4',
        name: 'Free Range Eggs',
        description: 'Farm fresh free-range eggs',
        category: 'Dairy',
        price: 6.99,
        cost: 4.50,
        stockQuantity: 120,
        expirationDate: expirationDates[3],
        createdAt: new Date(2023, 0, 20),
        updatedAt: new Date(2023, 0, 20),
        status: ProductStatus.ACTIVE,
        image: 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg?auto=compress&cs=tinysrgb&w=300'
      },
      {
        id: '5',
        name: 'Premium Coffee Beans',
        description: 'Artisan roasted premium coffee beans',
        category: 'Beverages',
        price: 14.99,
        cost: 9.00,
        stockQuantity: 80,
        expirationDate: expirationDates[5],
        createdAt: new Date(2023, 1, 5),
        updatedAt: new Date(2023, 1, 5),
        status: ProductStatus.ACTIVE,
        image: 'https://images.pexels.com/photos/1695052/pexels-photo-1695052.jpeg?auto=compress&cs=tinysrgb&w=300'
      },
      {
        id: '6',
        name: 'Organic Bananas',
        description: 'Organic bananas from sustainable farms',
        category: 'Fruits',
        price: 2.99,
        cost: 1.50,
        stockQuantity: 200,
        expirationDate: expirationDates[0],
        createdAt: new Date(2023, 1, 10),
        updatedAt: new Date(2023, 1, 10),
        status: ProductStatus.ACTIVE,
        image: 'https://images.pexels.com/photos/5966431/pexels-photo-5966431.jpeg?auto=compress&cs=tinysrgb&w=300'
      },
      {
        id: '7',
        name: 'Grass-Fed Ground Beef',
        description: 'Pasture-raised grass-fed ground beef',
        category: 'Meat',
        price: 8.99,
        cost: 6.00,
        stockQuantity: 50,
        expirationDate: expirationDates[1],
        createdAt: new Date(2023, 1, 15),
        updatedAt: new Date(2023, 1, 15),
        status: ProductStatus.ACTIVE,
        image: 'https://images.pexels.com/photos/618775/pexels-photo-618775.jpeg?auto=compress&cs=tinysrgb&w=300'
      },
      {
        id: '8',
        name: 'Organic Spinach',
        description: 'Fresh organic spinach from local farms',
        category: 'Vegetables',
        price: 3.49,
        cost: 1.80,
        stockQuantity: 90,
        expirationDate: expirationDates[0],
        createdAt: new Date(2023, 1, 20),
        updatedAt: new Date(2023, 1, 20),
        status: ProductStatus.ACTIVE,
        image: 'https://images.pexels.com/photos/2255935/pexels-photo-2255935.jpeg?auto=compress&cs=tinysrgb&w=300'
      },
      {
        id: '9',
        name: 'Artisan Cheese',
        description: 'Locally produced artisan cheese',
        category: 'Dairy',
        price: 9.99,
        cost: 6.50,
        stockQuantity: 60,
        expirationDate: expirationDates[2],
        createdAt: new Date(2023, 2, 1),
        updatedAt: new Date(2023, 2, 1),
        status: ProductStatus.ACTIVE,
        image: 'https://images.pexels.com/photos/821365/pexels-photo-821365.jpeg?auto=compress&cs=tinysrgb&w=300'
      },
      {
        id: '10',
        name: 'Sourdough Bread',
        description: 'Traditional sourdough bread',
        category: 'Bakery',
        price: 5.99,
        cost: 3.00,
        stockQuantity: 0,
        expirationDate: expirationDates[1],
        createdAt: new Date(2023, 2, 5),
        updatedAt: new Date(2023, 2, 5),
        status: ProductStatus.OUT_OF_STOCK,
        image: 'https://images.pexels.com/photos/2286776/pexels-photo-2286776.jpeg?auto=compress&cs=tinysrgb&w=300'
      }
    ];
    
    this.productsSignal.set(mockProducts);
  }
}