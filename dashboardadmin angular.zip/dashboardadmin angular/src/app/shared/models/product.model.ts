export interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  price: number;
  cost: number;
  stockQuantity: number;
  expirationDate?: Date;
  createdAt: Date;
  updatedAt: Date;
  status: ProductStatus;
  image?: string;
}

export enum ProductStatus {
  ACTIVE = 'ACTIVE',
  DISCONTINUED = 'DISCONTINUED',
  OUT_OF_STOCK = 'OUT_OF_STOCK'
}

export interface ProductCategory {
  id: string;
  name: string;
  description?: string;
}