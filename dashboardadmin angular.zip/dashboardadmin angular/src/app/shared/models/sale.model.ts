export interface Sale {
  id: string;
  customerId?: string;
  customerName?: string;
  total: number;
  tax: number;
  discount: number;
  paymentMethod: PaymentMethod;
  status: SaleStatus;
  items: SaleItem[];
  createdAt: Date;
  updatedAt: Date;
  salesPerson: string;
}

export interface SaleItem {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  total: number;
}

export enum PaymentMethod {
  CASH = 'CASH',
  CREDIT_CARD = 'CREDIT_CARD',
  DEBIT_CARD = 'DEBIT_CARD',
  BANK_TRANSFER = 'BANK_TRANSFER',
  OTHER = 'OTHER'
}

export enum SaleStatus {
  COMPLETED = 'COMPLETED',
  PENDING = 'PENDING',
  CANCELLED = 'CANCELLED',
  REFUNDED = 'REFUNDED'
}

export interface SaleSummary {
  totalSales: number;
  totalRevenue: number;
  averageOrderValue: number;
  period: string;
}