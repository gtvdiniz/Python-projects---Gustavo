import { Component, Input, ElementRef, ViewChild, AfterViewInit, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-chart',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="chart-container">
      <canvas #chartCanvas></canvas>
    </div>
  `,
  styles: [`
    .chart-container {
      width: 100%;
      height: 100%;
      min-height: 200px;
    }
  `]
})
export class ChartComponent implements AfterViewInit, OnChanges {
  @ViewChild('chartCanvas') chartCanvas!: ElementRef<HTMLCanvasElement>;
  @Input() type: 'line' | 'bar' | 'pie' | 'doughnut' = 'line';
  @Input() data: any = {};
  @Input() options: any = {};
  
  private chart: any;
  private chartLibrary: any;
  
  constructor() {}
  
  ngAfterViewInit(): void {
    this.loadChartLibrary().then(() => {
      this.renderChart();
    });
  }
  
  ngOnChanges(changes: SimpleChanges): void {
    if ((changes['data'] || changes['options']) && this.chart) {
      this.updateChart();
    }
  }
  
  private async loadChartLibrary(): Promise<void> {
    if (typeof window !== 'undefined' && !(window as any).Chart) {
      // Load Chart.js library
      const chartScript = document.createElement('script');
      chartScript.src = 'https://cdn.jsdelivr.net/npm/chart.js';
      chartScript.async = true;
      
      document.body.appendChild(chartScript);
      
      await new Promise((resolve) => {
        chartScript.onload = resolve;
      });
    }
    
    this.chartLibrary = (window as any).Chart;
  }
  
  private renderChart(): void {
    if (this.chartLibrary && this.chartCanvas) {
      const ctx = this.chartCanvas.nativeElement.getContext('2d');
      
      if (ctx) {
        this.chart = new this.chartLibrary(ctx, {
          type: this.type,
          data: this.data,
          options: this.getChartOptions()
        });
      }
    }
  }
  
  private updateChart(): void {
    if (this.chart) {
      this.chart.data = this.data;
      this.chart.options = this.getChartOptions();
      this.chart.update();
    }
  }
  
  private getChartOptions(): any {
    // Default options based on chart type
    const defaultOptions: any = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: 'top',
          labels: {
            boxWidth: 20,
            font: {
              size: 12
            }
          }
        },
        tooltip: {
          mode: 'index',
          intersect: false,
          backgroundColor: 'rgba(255, 255, 255, 0.9)',
          titleColor: '#212121',
          bodyColor: '#616161',
          borderColor: '#E0E0E0',
          borderWidth: 1,
          cornerRadius: 4,
          padding: 8,
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          usePointStyle: true
        }
      }
    };
    
    // Line chart specific defaults
    if (this.type === 'line') {
      defaultOptions.scales = {
        x: {
          grid: {
            display: false
          }
        },
        y: {
          grid: {
            borderDash: [2, 2]
          },
          beginAtZero: true
        }
      };
      
      defaultOptions.elements = {
        line: {
          tension: 0.4
        },
        point: {
          radius: 4,
          hoverRadius: 6
        }
      };
    }
    
    // Bar chart specific defaults
    if (this.type === 'bar') {
      defaultOptions.scales = {
        x: {
          grid: {
            display: false
          }
        },
        y: {
          grid: {
            borderDash: [2, 2]
          },
          beginAtZero: true
        }
      };
      
      defaultOptions.plugins.tooltip.callbacks = {
        label: function(context: any) {
          return `${context.dataset.label}: ${context.formattedValue}`;
        }
      };
    }
    
    // Pie/Doughnut specific defaults
    if (this.type === 'pie' || this.type === 'doughnut') {
      defaultOptions.plugins.tooltip.callbacks = {
        label: function(context: any) {
          const label = context.label || '';
          const value = context.formattedValue;
          const total = context.chart.data.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
          const percentage = Math.round((context.raw / total) * 100);
          return `${label}: ${value} (${percentage}%)`;
        }
      };
    }
    
    // Merge with user options
    return {
      ...defaultOptions,
      ...this.options
    };
  }
}