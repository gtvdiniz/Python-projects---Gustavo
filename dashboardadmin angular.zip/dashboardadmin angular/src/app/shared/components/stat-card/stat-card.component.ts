import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-stat-card',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="stat-card" [ngClass]="'stat-' + type">
      <div class="stat-icon" *ngIf="icon">
        <ng-container *ngTemplateOutlet="icon"></ng-container>
      </div>
      <div class="stat-content">
        <div class="stat-title">{{ title }}</div>
        <div class="stat-value">{{ value }}</div>
        <div class="stat-change" *ngIf="change !== undefined">
          <svg 
            *ngIf="change > 0" 
            xmlns="http://www.w3.org/2000/svg" 
            height="16" 
            viewBox="0 -960 960 960" 
            width="16" 
            fill="currentColor"
          >
            <path d="m438-240-36-38 124-124H200v-54h326L402-580l38-36 202 202-204 174Z"/>
          </svg>
          <svg 
            *ngIf="change < 0" 
            xmlns="http://www.w3.org/2000/svg" 
            height="16" 
            viewBox="0 -960 960 960" 
            width="16" 
            fill="currentColor"
          >
            <path d="M438-720 400-682l124 124H200v54h324L400-380l38 38 204-176-204-202Z"/>
          </svg>
          <span [class.positive]="change > 0" [class.negative]="change < 0">
            {{ change > 0 ? '+' : '' }}{{ change }}% {{ changeLabel }}
          </span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .stat-card {
      display: flex;
      align-items: center;
      background-color: white;
      border-radius: var(--radius-md);
      padding: var(--spacing-3);
      box-shadow: var(--shadow-sm);
      transition: transform var(--transition-fast);
      overflow: hidden;
      position: relative;
    }
    
    .stat-card:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    .stat-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 6px;
      height: 100%;
      background-color: var(--primary-500);
    }
    
    .stat-primary::before {
      background-color: var(--primary-500);
    }
    
    .stat-success::before {
      background-color: var(--success);
    }
    
    .stat-warning::before {
      background-color: var(--warning);
    }
    
    .stat-error::before {
      background-color: var(--error);
    }
    
    .stat-info::before {
      background-color: var(--info);
    }
    
    .stat-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 48px;
      height: 48px;
      background-color: var(--primary-100);
      color: var(--primary-700);
      border-radius: var(--radius-sm);
      margin-right: var(--spacing-2);
      flex-shrink: 0;
    }
    
    .stat-primary .stat-icon {
      background-color: var(--primary-100);
      color: var(--primary-700);
    }
    
    .stat-success .stat-icon {
      background-color: rgba(76, 175, 80, 0.1);
      color: var(--success);
    }
    
    .stat-warning .stat-icon {
      background-color: rgba(255, 193, 7, 0.1);
      color: var(--warning);
    }
    
    .stat-error .stat-icon {
      background-color: rgba(244, 67, 54, 0.1);
      color: var(--error);
    }
    
    .stat-info .stat-icon {
      background-color: rgba(33, 150, 243, 0.1);
      color: var(--info);
    }
    
    .stat-content {
      flex: 1;
    }
    
    .stat-title {
      font-size: 0.875rem;
      color: var(--neutral-600);
      margin-bottom: 4px;
    }
    
    .stat-value {
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--neutral-900);
      margin-bottom: 4px;
    }
    
    .stat-change {
      display: flex;
      align-items: center;
      font-size: 0.75rem;
    }
    
    .stat-change svg {
      margin-right: 4px;
    }
    
    .positive {
      color: var(--success);
    }
    
    .negative {
      color: var(--error);
    }
  `]
})
export class StatCardComponent {
  @Input() title = '';
  @Input() value = '';
  @Input() change?: number;
  @Input() changeLabel = 'vs last period';
  @Input() type: 'primary' | 'success' | 'warning' | 'error' | 'info' = 'primary';
  @Input() icon?: any;
}