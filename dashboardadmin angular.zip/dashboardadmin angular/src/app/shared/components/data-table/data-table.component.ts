import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface TableColumn {
  key: string;
  title: string;
  type?: 'text' | 'date' | 'number' | 'currency' | 'status' | 'image';
  sortable?: boolean;
  width?: string;
}

@Component({
  selector: 'app-data-table',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="data-table-container">
      <div class="data-table-header">
        <div class="search-container" *ngIf="showSearch">
          <input
            type="text"
            placeholder="Search..."
            class="search-input"
            [value]="searchTerm"
            (input)="onSearch($event)"
          />
          <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20" fill="currentColor">
            <path d="M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z"/>
          </svg>
        </div>
        <div class="table-actions">
          <ng-content select="[tableActions]"></ng-content>
        </div>
      </div>
      
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th *ngFor="let column of columns" [style.width]="column.width">
                <div class="th-content">
                  {{ column.title }}
                  <div class="sort-icons" *ngIf="column.sortable">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      height="16"
                      viewBox="0 -960 960 960" 
                      width="16"
                      fill="currentColor"
                      [class.active]="sortColumn === column.key && sortDirection === 'asc'"
                      (click)="onSort(column.key, 'asc')"
                    >
                      <path d="M480-528 296-344l-56-56 240-240 240 240-56 56-184-184Z"/>
                    </svg>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      height="16"
                      viewBox="0 -960 960 960" 
                      width="16"
                      fill="currentColor"
                      [class.active]="sortColumn === column.key && sortDirection === 'desc'"
                      (click)="onSort(column.key, 'desc')"
                    >
                      <path d="m296-344 184-184 184 184-56 56-128-128-128 128-56-56Z"/>
                    </svg>
                  </div>
                </div>
              </th>
              <th *ngIf="showActions" style="width: 100px">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngIf="filteredData.length === 0">
              <td [attr.colspan]="showActions ? columns.length + 1 : columns.length" class="empty-message">
                {{ emptyMessage }}
              </td>
            </tr>
            <tr *ngFor="let item of filteredData" (click)="onRowClick(item)">
              <td *ngFor="let column of columns">
                <ng-container [ngSwitch]="column.type">
                  <ng-container *ngSwitchCase="'date'">
                    {{ item[column.key] | date:'short' }}
                  </ng-container>
                  <ng-container *ngSwitchCase="'currency'">
                    {{ item[column.key] | currency:'USD':'symbol':'1.2-2' }}
                  </ng-container>
                  <ng-container *ngSwitchCase="'status'">
                    <span class="status-badge" [class]="'status-' + item[column.key].toLowerCase()">
                      {{ item[column.key] }}
                    </span>
                  </ng-container>
                  <ng-container *ngSwitchCase="'image'">
                    <img *ngIf="item[column.key]" [src]="item[column.key]" alt="Image" class="table-image" />
                    <div *ngIf="!item[column.key]" class="no-image">No image</div>
                  </ng-container>
                  <ng-container *ngSwitchDefault>
                    {{ item[column.key] }}
                  </ng-container>
                </ng-container>
              </td>
              <td *ngIf="showActions">
                <div class="actions-cell">
                  <button class="icon-button" (click)="$event.stopPropagation(); onEdit(item)">
                    <svg xmlns="http://www.w3.org/2000/svg" height="18" viewBox="0 -960 960 960" width="18" fill="currentColor">
                      <path d="M200-200h56l345-345-56-56-345 345v56Zm572-403L602-773l56-56q23-23 56.5-23t56.5 23l56 56q23 23 24 55.5T829-661l-57 58Zm-58 59L290-120H120v-170l424-424 170 170Zm-141-29-28-28 56 56-28-28Z"/>
                    </svg>
                  </button>
                  <button class="icon-button" (click)="$event.stopPropagation(); onDelete(item)">
                    <svg xmlns="http://www.w3.org/2000/svg" height="18" viewBox="0 -960 960 960" width="18" fill="currentColor">
                      <path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z"/>
                    </svg>
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <div class="pagination" *ngIf="showPagination && data.length > pageSize">
        <div class="pagination-info">
          Showing {{ (currentPage - 1) * pageSize + 1 }} to {{ Math.min(currentPage * pageSize, data.length) }} of {{ data.length }} entries
        </div>
        <div class="pagination-controls">
          <button 
            class="pagination-button" 
            [disabled]="currentPage === 1"
            (click)="changePage(currentPage - 1)"
          >
            <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20" fill="currentColor">
              <path d="M560-240 320-480l240-240 56 56-184 184 184 184-56 56Z"/>
            </svg>
          </button>
          <span class="pagination-page">Page {{ currentPage }} of {{ totalPages }}</span>
          <button 
            class="pagination-button" 
            [disabled]="currentPage === totalPages"
            (click)="changePage(currentPage + 1)"
          >
            <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20" fill="currentColor">
              <path d="M400-240 360-296l184-184-184-184 40-56 240 240-240 240Z"/>
            </svg>
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .data-table-container {
      background-color: white;
      border-radius: var(--radius-md);
      box-shadow: var(--shadow-sm);
      overflow: hidden;
    }
    
    .data-table-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: var(--spacing-2) var(--spacing-3);
      border-bottom: 1px solid var(--neutral-200);
    }
    
    .search-container {
      position: relative;
      width: 240px;
    }
    
    .search-input {
      width: 100%;
      padding: var(--spacing-1) var(--spacing-3);
      padding-left: var(--spacing-4);
      border: 1px solid var(--neutral-300);
      border-radius: var(--radius-sm);
      outline: none;
      transition: border-color var(--transition-fast);
    }
    
    .search-input:focus {
      border-color: var(--primary-400);
    }
    
    .search-container svg {
      position: absolute;
      left: 8px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--neutral-500);
    }
    
    .table-responsive {
      overflow-x: auto;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 0;
    }
    
    th {
      text-align: left;
      padding: var(--spacing-2) var(--spacing-3);
      background-color: var(--neutral-50);
      border-bottom: 2px solid var(--neutral-300);
      font-weight: 500;
      color: var(--neutral-700);
    }
    
    .th-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    .sort-icons {
      display: flex;
      flex-direction: column;
      margin-left: var(--spacing-1);
      cursor: pointer;
    }
    
    .sort-icons svg {
      color: var(--neutral-400);
      transition: color var(--transition-fast);
    }
    
    .sort-icons svg:hover, .sort-icons svg.active {
      color: var(--primary-600);
    }
    
    td {
      padding: var(--spacing-2) var(--spacing-3);
      border-bottom: 1px solid var(--neutral-200);
      transition: background-color var(--transition-fast);
    }
    
    tr:hover td {
      background-color: var(--primary-50);
    }
    
    .empty-message {
      text-align: center;
      padding: var(--spacing-4) !important;
      color: var(--neutral-600);
    }
    
    .status-badge {
      display: inline-block;
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 500;
      text-transform: capitalize;
    }
    
    .status-active {
      background-color: var(--success);
      color: white;
    }
    
    .status-inactive {
      background-color: var(--neutral-400);
      color: var(--neutral-700);
    }
    
    .status-suspended {
      background-color: var(--error);
      color: white;
    }
    
    .status-pending {
      background-color: var(--warning);
      color: var(--neutral-900);
    }
    
    .status-completed {
      background-color: var(--success);
      color: white;
    }
    
    .status-cancelled {
      background-color: var(--error);
      color: white;
    }
    
    .status-out_of_stock {
      background-color: var(--error);
      color: white;
    }
    
    .table-image {
      width: 40px;
      height: 40px;
      object-fit: cover;
      border-radius: var(--radius-sm);
    }
    
    .no-image {
      width: 40px;
      height: 40px;
      border-radius: var(--radius-sm);
      background-color: var(--neutral-200);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.6rem;
      color: var(--neutral-600);
      text-align: center;
    }
    
    .actions-cell {
      display: flex;
      gap: var(--spacing-1);
      justify-content: center;
    }
    
    .icon-button {
      background: none;
      border: none;
      cursor: pointer;
      color: var(--neutral-700);
      padding: 4px;
      border-radius: var(--radius-sm);
      transition: background-color var(--transition-fast);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .icon-button:hover {
      background-color: var(--neutral-200);
      color: var(--primary-600);
    }
    
    .pagination {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: var(--spacing-2) var(--spacing-3);
      border-top: 1px solid var(--neutral-200);
    }
    
    .pagination-info {
      font-size: 0.875rem;
      color: var(--neutral-600);
    }
    
    .pagination-controls {
      display: flex;
      align-items: center;
      gap: var(--spacing-1);
    }
    
    .pagination-button {
      background: none;
      border: 1px solid var(--neutral-300);
      border-radius: var(--radius-sm);
      padding: 4px 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: background-color var(--transition-fast);
    }
    
    .pagination-button:hover:not(:disabled) {
      background-color: var(--neutral-100);
    }
    
    .pagination-button:disabled {
      opacity: 0.5;
      cursor: default;
    }
    
    .pagination-page {
      font-size: 0.875rem;
      color: var(--neutral-700);
    }
  `]
})
export class DataTableComponent {
  @Input() columns: TableColumn[] = [];
  @Input() data: any[] = [];
  @Input() showSearch = true;
  @Input() showActions = true;
  @Input() showPagination = true;
  @Input() pageSize = 10;
  @Input() emptyMessage = 'No data available';
  
  @Output() rowClick = new EventEmitter<any>();
  @Output() edit = new EventEmitter<any>();
  @Output() delete = new EventEmitter<any>();
  @Output() sort = new EventEmitter<{column: string, direction: 'asc' | 'desc'}>();
  
  searchTerm = '';
  sortColumn = '';
  sortDirection: 'asc' | 'desc' = 'asc';
  currentPage = 1;
  
  Math = Math;
  
  get filteredData(): any[] {
    let filtered = [...this.data];
    
    // Apply search filter
    if (this.searchTerm) {
      const term = this.searchTerm.toLowerCase();
      filtered = filtered.filter(item => {
        return Object.keys(item).some(key => {
          const value = item[key];
          if (value === null || value === undefined) return false;
          return value.toString().toLowerCase().includes(term);
        });
      });
    }
    
    // Apply sort
    if (this.sortColumn) {
      filtered.sort((a, b) => {
        let valueA = a[this.sortColumn];
        let valueB = b[this.sortColumn];
        
        // Handle date values
        if (valueA instanceof Date && valueB instanceof Date) {
          valueA = valueA.getTime();
          valueB = valueB.getTime();
        }
        
        // Handle string values
        if (typeof valueA === 'string' && typeof valueB === 'string') {
          valueA = valueA.toLowerCase();
          valueB = valueB.toLowerCase();
        }
        
        if (valueA < valueB) return this.sortDirection === 'asc' ? -1 : 1;
        if (valueA > valueB) return this.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });
    }
    
    // Apply pagination
    if (this.showPagination) {
      const start = (this.currentPage - 1) * this.pageSize;
      filtered = filtered.slice(start, start + this.pageSize);
    }
    
    return filtered;
  }
  
  get totalPages(): number {
    return Math.ceil(this.data.length / this.pageSize);
  }
  
  onSearch(event: Event): void {
    this.searchTerm = (event.target as HTMLInputElement).value;
    this.currentPage = 1;
  }
  
  onSort(column: string, direction: 'asc' | 'desc'): void {
    if (this.sortColumn === column && this.sortDirection === direction) {
      // Reset sort
      this.sortColumn = '';
      this.sortDirection = 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = direction;
    }
    
    this.sort.emit({ column: this.sortColumn, direction: this.sortDirection });
  }
  
  changePage(page: number): void {
    if (page < 1 || page > this.totalPages) return;
    this.currentPage = page;
  }
  
  onRowClick(item: any): void {
    this.rowClick.emit(item);
  }
  
  onEdit(item: any): void {
    this.edit.emit(item);
  }
  
  onDelete(item: any): void {
    this.delete.emit(item);
  }
}