import { Component, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-date-filter',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="date-filter">
      <div class="filter-buttons">
        <button 
          class="filter-button" 
          [class.active]="selectedFilter === 'day'"
          (click)="setFilter('day')"
        >
          Today
        </button>
        <button 
          class="filter-button" 
          [class.active]="selectedFilter === 'week'"
          (click)="setFilter('week')"
        >
          This Week
        </button>
        <button 
          class="filter-button" 
          [class.active]="selectedFilter === 'month'"
          (click)="setFilter('month')"
        >
          This Month
        </button>
        <button 
          class="filter-button" 
          [class.active]="selectedFilter === 'year'"
          (click)="setFilter('year')"
        >
          This Year
        </button>
        <button 
          class="filter-button" 
          [class.active]="selectedFilter === 'custom'"
          (click)="setFilter('custom')"
        >
          Custom
        </button>
      </div>
      
      <div class="custom-date-range" *ngIf="selectedFilter === 'custom'">
        <div class="form-group">
          <label for="startDate" class="form-label">Start Date</label>
          <input 
            type="date" 
            id="startDate" 
            class="form-control" 
            [(ngModel)]="startDate"
            (change)="applyCustomFilter()"
          />
        </div>
        <div class="form-group">
          <label for="endDate" class="form-label">End Date</label>
          <input 
            type="date" 
            id="endDate" 
            class="form-control" 
            [(ngModel)]="endDate"
            (change)="applyCustomFilter()"
          />
        </div>
        <button 
          class="btn btn-primary btn-sm"
          (click)="applyCustomFilter()"
        >
          Apply
        </button>
      </div>
    </div>
  `,
  styles: [`
    .date-filter {
      margin-bottom: var(--spacing-3);
    }
    
    .filter-buttons {
      display: flex;
      flex-wrap: wrap;
      gap: var(--spacing-1);
      margin-bottom: var(--spacing-2);
    }
    
    .filter-button {
      padding: 6px 12px;
      border: 1px solid var(--neutral-300);
      background-color: white;
      border-radius: var(--radius-sm);
      cursor: pointer;
      font-size: 0.875rem;
      transition: background-color var(--transition-fast);
    }
    
    .filter-button:hover {
      background-color: var(--neutral-100);
    }
    
    .filter-button.active {
      background-color: var(--primary-500);
      color: white;
      border-color: var(--primary-600);
    }
    
    .custom-date-range {
      display: flex;
      flex-wrap: wrap;
      gap: var(--spacing-2);
      align-items: flex-end;
      background-color: var(--neutral-50);
      padding: var(--spacing-2);
      border-radius: var(--radius-md);
      border: 1px solid var(--neutral-200);
    }
    
    .form-group {
      flex: 1;
      min-width: 200px;
    }
    
    .btn-sm {
      padding: 6px 12px;
      font-size: 0.875rem;
    }
    
    @media (max-width: 768px) {
      .filter-buttons {
        overflow-x: auto;
        padding-bottom: var(--spacing-1);
        margin-bottom: var(--spacing-1);
      }
      
      .filter-button {
        flex-shrink: 0;
      }
      
      .custom-date-range {
        flex-direction: column;
      }
    }
  `]
})
export class DateFilterComponent {
  @Output() filterChange = new EventEmitter<{type: string, startDate?: Date, endDate?: Date}>();
  
  selectedFilter: 'day' | 'week' | 'month' | 'year' | 'custom' = 'month';
  startDate: string = '';
  endDate: string = '';
  
  constructor() {
    // Initialize with default filter
    this.setFilter('month');
    
    // Initialize custom date range with current month
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    this.startDate = this.formatDate(firstDayOfMonth);
    this.endDate = this.formatDate(today);
  }
  
  setFilter(filter: 'day' | 'week' | 'month' | 'year' | 'custom'): void {
    this.selectedFilter = filter;
    
    if (filter !== 'custom') {
      this.filterChange.emit({ type: filter });
    } else {
      this.applyCustomFilter();
    }
  }
  
  applyCustomFilter(): void {
    if (this.startDate && this.endDate) {
      const startDate = new Date(this.startDate);
      const endDate = new Date(this.endDate);
      
      // Set end date to end of day
      endDate.setHours(23, 59, 59, 999);
      
      this.filterChange.emit({
        type: 'custom',
        startDate,
        endDate
      });
    }
  }
  
  private formatDate(date: Date): string {
    return date.toISOString().split('T')[0];
  }
}