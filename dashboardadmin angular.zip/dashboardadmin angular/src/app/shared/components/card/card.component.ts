import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-card',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="card" [class.card-bordered]="bordered">
      <div class="card-header" *ngIf="title || subtitle">
        <div class="card-title">
          <h3>{{ title }}</h3>
          <p *ngIf="subtitle">{{ subtitle }}</p>
        </div>
        <div class="card-actions" *ngIf="showActions">
          <ng-content select="[card-actions]"></ng-content>
        </div>
      </div>
      <div class="card-body">
        <ng-content></ng-content>
      </div>
      <div class="card-footer" *ngIf="showFooter">
        <ng-content select="[card-footer]"></ng-content>
      </div>
    </div>
  `,
  styles: [`
    .card {
      background-color: white;
      border-radius: var(--radius-md);
      box-shadow: var(--shadow-sm);
      overflow: hidden;
      transition: box-shadow var(--transition-fast);
    }
    
    .card:hover {
      box-shadow: var(--shadow-md);
    }
    
    .card-bordered {
      border: 1px solid var(--neutral-200);
    }
    
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      padding: var(--spacing-3);
      border-bottom: 1px solid var(--neutral-200);
    }
    
    .card-title {
      flex: 1;
    }
    
    .card-title h3 {
      margin: 0;
      font-size: 1.25rem;
      color: var(--neutral-900);
    }
    
    .card-title p {
      margin: var(--spacing-1) 0 0;
      color: var(--neutral-600);
      font-size: 0.875rem;
    }
    
    .card-actions {
      display: flex;
      gap: var(--spacing-1);
    }
    
    .card-body {
      padding: var(--spacing-3);
    }
    
    .card-footer {
      padding: var(--spacing-3);
      border-top: 1px solid var(--neutral-200);
      background-color: var(--neutral-50);
    }
  `]
})
export class CardComponent {
  @Input() title = '';
  @Input() subtitle = '';
  @Input() bordered = false;
  @Input() showActions = false;
  @Input() showFooter = false;
}