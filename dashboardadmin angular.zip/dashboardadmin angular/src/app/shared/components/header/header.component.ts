import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { User } from '../../../shared/models/user.model';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <header class="header">
      <div class="header-left">
        <button class="menu-toggle" (click)="toggleSidebar.emit()">
          <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor">
            <path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z"/>
          </svg>
        </button>
        <div class="logo">
          <a routerLink="/dashboard">
            <img src="../../../imagem/images.jpeg" alt="Torre Verde" />
            <span>Torre Verde Admin</span>
          </a>
        </div>
      </div>
      <div class="header-right">
        <div class="search-container">
          <input type="text" placeholder="Buscar..." class="search-input" />
          <button class="search-button">
            <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20" fill="currentColor">
              <path d="M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z"/>
            </svg>
          </button>
        </div>
        <div class="notifications">
          <button class="icon-button">
            <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor">
              <path d="M160-200v-80h80v-280q0-83 50-147.5T420-792v-28q0-25 17.5-42.5T480-880q25 0 42.5 17.5T540-820v28q80 20 130 84.5T720-560v280h80v80H160Zm320-300Zm0 420q-33 0-56.5-23.5T400-160h160q0 33-23.5 56.5T480-80ZM320-280h320v-280q0-66-47-113t-113-47q-66 0-113 47t-47 113v280Z"/>
            </svg>
            <span class="badge">3</span>
          </button>
        </div>
        <div class="user-menu" *ngIf="currentUser">
          <div class="user-info" (click)="isUserMenuOpen = !isUserMenuOpen">
            <img [src]="currentUser.avatar || 'https://via.placeholder.com/40x40'" alt="User" class="avatar" />
            <span class="d-none d-md-inline">{{ currentUser.name }}</span>
            <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20" fill="currentColor" class="d-none d-md-inline">
              <path d="M480-344 240-584l56-56 184 184 184-184 56 56-240 240Z"/>
            </svg>
          </div>
          <div class="dropdown-menu" *ngIf="isUserMenuOpen">
            <ul>
              <li><a routerLink="/profile">My Profile</a></li>
              <li><a routerLink="/settings">Settings</a></li>
              <li><a (click)="logout.emit()">Logout</a></li>
            </ul>
          </div>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: white;
      padding: 0 var(--spacing-2);
      height: 64px;
      box-shadow: var(--shadow-sm);
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
    }
    
    .header-left, .header-right {
      display: flex;
      align-items: center;
    }
    
    .menu-toggle {
      background: none;
      border: none;
      cursor: pointer;
      color: var(--neutral-700);
      margin-right: var(--spacing-2);
      padding: var(--spacing-1);
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: var(--radius-sm);
      transition: background-color var(--transition-fast);
    }
    
    .menu-toggle:hover {
      background-color: var(--neutral-100);
    }
    
    .logo {
      display: flex;
      align-items: center;
    }
    
    .logo a {
      display: flex;
      align-items: center;
      text-decoration: none;
      color: var(--neutral-900);
      font-weight: 600;
    }
    
    .logo img {
    
    }
    
    .search-container {
      display: flex;
      align-items: center;
      background-color: var(--neutral-100);
      border-radius: var(--radius-sm);
      padding: 0 var(--spacing-1);
      margin-right: var(--spacing-2);
    }
    
    .search-input {
      border: none;
      background: transparent;
      padding: var(--spacing-1) var(--spacing-2);
      outline: none;
      width: 200px;
    }
    
    .search-button {
      background: none;
      border: none;
      cursor: pointer;
      color: var(--neutral-500);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .search-button:hover {
      color: var(--neutral-900);
    }
    
    .icon-button {
      background: none;
      border: none;
      cursor: pointer;
      color: var(--neutral-700);
      padding: var(--spacing-1);
      margin-right: var(--spacing-2);
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      border-radius: var(--radius-sm);
      transition: background-color var(--transition-fast);
    }
    
    .icon-button:hover {
      background-color: var(--neutral-100);
    }
    
    .badge {
      position: absolute;
      top: 0;
      right: 0;
      background-color: var(--error);
      color: white;
      font-size: 0.6rem;
      padding: 2px 4px;
      border-radius: 10px;
      min-width: 14px;
      text-align: center;
    }
    
    .user-menu {
      position: relative;
    }
    
    .user-info {
      display: flex;
      align-items: center;
      cursor: pointer;
      padding: var(--spacing-1);
      border-radius: var(--radius-sm);
      transition: background-color var(--transition-fast);
    }
    
    .user-info:hover {
      background-color: var(--neutral-100);
    }
    
    .avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      margin-right: var(--spacing-1);
    }
    
    .dropdown-menu {
      position: absolute;
      top: 100%;
      right: 0;
      background-color: white;
      border-radius: var(--radius-md);
      box-shadow: var(--shadow-md);
      min-width: 180px;
      padding: var(--spacing-1) 0;
      margin-top: var(--spacing-1);
      z-index: 1001;
    }
    
    .dropdown-menu ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .dropdown-menu li {
      padding: 0;
    }
    
    .dropdown-menu a {
      display: block;
      padding: var(--spacing-1) var(--spacing-2);
      color: var(--neutral-900);
      text-decoration: none;
      transition: background-color var(--transition-fast);
      cursor: pointer;
    }
    
    .dropdown-menu a:hover {
      background-color: var(--neutral-100);
    }
    
    @media (max-width: 768px) {
      .search-container {
        width: 40px;
        overflow: hidden;
        transition: width var(--transition-medium);
      }
      
      .search-container:focus-within {
        width: 200px;
      }
      
      .logo span {
        display: none;
      }
    }
  `]
})
export class HeaderComponent {
  @Input() currentUser: User | null = null;
  @Output() toggleSidebar = new EventEmitter<void>();
  @Output() logout = new EventEmitter<void>();
  
  isUserMenuOpen = false;
}