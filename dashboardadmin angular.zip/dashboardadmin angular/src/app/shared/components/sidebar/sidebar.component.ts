import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { User, UserRole } from '../../../shared/models/user.model';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <aside [class]="'sidebar ' + (isOpen ? 'open' : 'closed')">
      <div class="sidebar-header">
        <div class="logo">
          <img src="../../../imagem/images.jpeg" alt="Torre Verde" />
          <span *ngIf="isOpen">Torre Verde</span>
        </div>
      </div>
      <nav class="sidebar-nav">
        <ul>
          <li>
            <a routerLink="/dashboard" routerLinkActive="active">
              <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor">
                <path d="M520-600v-240h320v240H520ZM120-440v-400h320v400H120Zm400 320v-400h320v400H520Zm-400 0v-240h320v240H120Zm80-400h160v-240H200v240Zm400 320h160v-240H600v240Zm0-480h160v-80H600v80ZM200-200h160v-80H200v80Zm0 0v-80 80Zm400 0v-240 240Zm0-480v-80 80Zm-400 80v-240 240Z"/>
              </svg>
              <span *ngIf="isOpen">Dashboard</span>
            </a>
          </li>
          <li>
            <a routerLink="/users" routerLinkActive="active">
              <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor">
                <path d="M400-480q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47ZM80-160v-112q0-33 17-62t47-44q51-26 115-44t141-18h14q6 0 12 2-8 18-13.5 37.5T404-360h-4q-71 0-127.5 18T180-306q-9 5-14.5 14t-5.5 20v32h252q6 19 15.5 37t21.5 33H80Zm560 40-12-60q-12-5-22.5-10.5T584-204l-58 18-40-68 46-40q-2-14-2-26t2-26l-46-40 40-68 58 18q11-8 21.5-13.5T628-460l12-60h80l12 60q12 5 22.5 11t21.5 15l58-20 40 70-46 40q2 12 2 25t-2 25l46 40-40 68-58-18q-11 8-21.5 13.5T732-180l-12 60h-80Zm40-120q33 0 56.5-23.5T760-320q0-33-23.5-56.5T680-400q-33 0-56.5 23.5T600-320q0 33 23.5 56.5T680-240ZM400-560q33 0 56.5-23.5T480-640q0-33-23.5-56.5T400-720q-33 0-56.5 23.5T320-640q0 33 23.5 56.5T400-560Zm0-80Zm-8 400Z"/>
              </svg>
              <span *ngIf="isOpen">Users</span>
            </a>
          </li>
          <li>
            <a routerLink="/sales" routerLinkActive="active">
              <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor">
                <path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v100h-80v-100H200v560h160v80H200Zm360-80q-33 0-56.5-23.5T480-280v-160q0-33 23.5-56.5T560-520h240q33 0 56.5 23.5T880-440v160q0 33-23.5 56.5T800-200H560Zm0-80h240v-160H560v160Zm120-80Z"/>
              </svg>
              <span *ngIf="isOpen">Sales</span>
            </a>
          </li>
          <li>
            <a routerLink="/products" routerLinkActive="active">
              <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor">
                <path d="M160-160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h640q33 0 56.5 23.5T880-720v480q0 33-23.5 56.5T800-160H160Zm0-80h640v-480H160v480Zm320-60q50 0 85-35t35-85q0-50-35-85t-85-35q-50 0-85 35t-35 85q0 50 35 85t85 35Zm0-80q-17 0-28.5-11.5T440-420q0-17 11.5-28.5T480-460q17 0 28.5 11.5T520-420q0 17-11.5 28.5T480-380ZM240-640h60v-60h-60v60Zm420 0h60v-60h-60v60ZM160-240v-480 480Z"/>
              </svg>
              <span *ngIf="isOpen">Products</span>
            </a>
          </li>
          <li *ngIf="currentUser?.role === 'ADMIN'">
            <a routerLink="/settings" routerLinkActive="active">
              <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor">
                <path d="m370-80-16-128q-13-5-24.5-12T307-235l-119 50L78-375l103-78q-1-7-1-13.5v-27q0-6.5 1-13.5L78-585l110-190 119 50q11-8 23-15t24-12l16-128h220l16 128q13 5 24.5 12t22.5 15l119-50 110 190-103 78q1 7 1 13.5v27q0 6.5-2 13.5l103 78-110 190-118-50q-11 8-23 15t-24 12L590-80H370Zm112-260q58 0 99-41t41-99q0-58-41-99t-99-41q-58 0-99 41t-41 99q0 58 41 99t99 41Zm0-80q-25 0-42.5-17.5T422-480q0-25 17.5-42.5T482-540q25 0 42.5 17.5T542-480q0 25-17.5 42.5T482-420Zm-2-60Zm-40 320h79l14-106q31-8 57.5-23.5T639-327l99 41 39-68-86-65q5-14 7-29.5t2-31.5q0-16-2-31.5t-7-29.5l86-65-39-68-99 42q-22-23-48.5-38.5T533-694l-13-106h-79l-14 106q-31 8-57.5 23.5T321-633l-99-41-39 68 86 64q-5 15-7 30t-2 32q0 16 2 31t7 30l-86 65 39 68 99-42q22 23 48.5 38.5T427-266l13 106Z"/>
              </svg>
              <span *ngIf="isOpen">Settings</span>
            </a>
          </li>
        </ul>
      </nav>
      <div class="sidebar-footer" *ngIf="isOpen">
        <div class="user-info">
          <img [src]="currentUser?.avatar || 'https://via.placeholder.com/40x40'" alt="User" class="avatar" />
          <div class="user-details">
            <div class="user-name">{{ currentUser?.name || 'User' }}</div>
            <div class="user-role">{{ currentUser?.role || 'Guest' }}</div>
          </div>
        </div>
      </div>
    </aside>
  `,
  styles: [`
    .sidebar {
      position: fixed;
      top: 64px;
      left: 0;
      bottom: 0;
      background-color: white;
      box-shadow: var(--shadow-sm);
      transition: width var(--transition-medium);
      overflow-x: hidden;
      z-index: 900;
      display: flex;
      flex-direction: column;
    }
    
    .sidebar.open {
      width: 240px;
    }
    
    .sidebar.closed {
      width: 64px;
    }
    
    .sidebar-header {
      padding: var(--spacing-2);
      border-bottom: 1px solid var(--neutral-200);
    }
    
    .logo {
      display: flex;
      align-items: center;
      height: 32px;
    }
    
    .logo img {
    
    }
    
    .logo span {
      font-weight: 600;
      color: var(--neutral-900);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .sidebar-nav {
      flex: 1;
      overflow-y: auto;
      padding: var(--spacing-2) 0;
    }
    
    .sidebar-nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .sidebar-nav li {
      margin-bottom: var(--spacing-1);
    }
    
    .sidebar-nav a {
      display: flex;
      align-items: center;
      padding: var(--spacing-1) var(--spacing-2);
      color: var(--neutral-700);
      text-decoration: none;
      transition: background-color var(--transition-fast);
      border-radius: var(--radius-sm);
    }
    
    .sidebar-nav a:hover {
      background-color: var(--neutral-100);
      color: var(--primary-600);
    }
    
    .sidebar-nav a.active {
      background-color: var(--primary-100);
      color: var(--primary-700);
    }
    
    .sidebar-nav a svg {
      margin-right: var(--spacing-2);
      flex-shrink: 0;
    }
    
    .sidebar-nav a span {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .sidebar-footer {
      padding: var(--spacing-2);
      border-top: 1px solid var(--neutral-200);
    }
    
    .user-info {
      display: flex;
      align-items: center;
    }
    
    .avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      margin-right: var(--spacing-1);
    }
    
    .user-details {
      overflow: hidden;
    }
    
    .user-name {
      font-weight: 500;
      color: var(--neutral-900);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .user-role {
      font-size: 0.75rem;
      color: var(--neutral-600);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  `]
})
export class SidebarComponent {
  @Input() isOpen = true;
  @Input() currentUser: User | null = null;
}