import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { HeaderComponent } from '../shared/components/header/header.component';
import { SidebarComponent } from '../shared/components/sidebar/sidebar.component';
import { AuthService } from '../core/services/auth.service';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    HeaderComponent,
    SidebarComponent
  ],
  template: `
    <app-header
      [currentUser]="authService.currentUser"
      (toggleSidebar)="toggleSidebar()"
      (logout)="logout()"
    ></app-header>
    
    <app-sidebar 
      [isOpen]="isSidebarOpen()" 
      [currentUser]="authService.currentUser"
    ></app-sidebar>
    
    <main class="main-content" [class.sidebar-open]="isSidebarOpen()">
      <router-outlet></router-outlet>
    </main>
  `,
  styles: [`
    .main-content {
      min-height: calc(100vh - 64px);
      margin-top: 64px;
      margin-left: 64px;
      transition: margin-left var(--transition-medium);
    }
    
    .main-content.sidebar-open {
      margin-left: 240px;
    }
    
    @media (max-width: 768px) {
      .main-content {
        margin-left: 0;
      }
      
      .main-content.sidebar-open {
        margin-left: 64px;
      }
    }
  `]
})
export class LayoutComponent {
  private isSidebarOpenSignal = signal<boolean>(true);
  
  constructor(public authService: AuthService) {}
  
  isSidebarOpen() {
    return this.isSidebarOpenSignal();
  }
  
  toggleSidebar(): void {
    this.isSidebarOpenSignal.update(value => !value);
  }
  
  logout(): void {
    this.authService.logout();
  }
}